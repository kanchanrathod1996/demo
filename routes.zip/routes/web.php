<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Tadmin\AdminLoginController;
use App\Http\Controllers\Tadmin\DashBoardController;
use App\Http\Controllers\Tadmin\AdminSettingsController;
use App\Http\Controllers\Tadmin\AdminProfileController;
use App\Http\Controllers\Tadmin\CategoryController;
use App\Http\Controllers\Tadmin\ProductController;
use App\Http\Controllers\Tadmin\AboutController;
use App\Http\Controllers\Tadmin\SliderController;
use App\Http\Controllers\Tadmin\TableController;
use App\Http\Controllers\Tadmin\UserController;
use App\Http\Controllers\Tadmin\IngredientTypeController;
use App\Http\Controllers\Tadmin\IngredientItemController;
use App\Http\Controllers\Tadmin\IngredientController;
use App\Http\Controllers\Tadmin\user\AboutusController;
use App\Http\Controllers\Tadmin\user\HomeController;
use App\Http\Controllers\Tadmin\user\MenuController;
use App\Http\Controllers\Tadmin\user\CartController;
use App\Http\Controllers\Tadmin\user\SignupController;
use App\Http\Controllers\Tadmin\user\LoginController;
use App\Http\Controllers\Tadmin\user\BookingController;
use App\Http\Controllers\Tadmin\user\InstamojoController;
use App\Http\Controllers\Tadmin\user\CheckoutController;
use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
// $password = '123';
// dd(bcrypt($password));
defined('ADMIN_SLUG') or define('ADMIN_SLUG', 'admin');

// Route::group(array('prefix' => ADMIN_SLUG), function () {
// Route::get('/', [AdminLoginController::class, 'login']);
// Route::post('/', [AdminLoginController::class, 'doLogin']);

// Route::group(array('middleware' => 'auth.admin'), function () {
//     Route::get('/dashboard', [DashboardController::class, 'index']);
//     Route::get('/addStudent', [DashboardController::class, 'create']);
//     Route::get('/delete/{id}', [DashboardController::class, 'destroy']);
//     Route::get('/edit/{id}', [DashboardController::class, 'update']);

//     Route::get('/logout', [AdminLoginController::class, 'doLogout']);

//     });
// });
// Route::get('/', function () {
//     return view('welcome');
// });

// Route::group(array('prefix' => ADMIN_SLUG), function () {
    
//     Route::get('/', [AdminLoginController::class, 'login']);
//     Route::post('/', [AdminLoginController::class, 'doLogin']);

//     Route::group(array('middleware' => 'auth.admin'), function () {
//         Route::get('/dashboard', [DashBoardController::class, 'index'])->name('dashboard.index');
//         Route::get('/logout', [AdminLoginController::class, 'doLogout']);
//         Route::resource('/settings', AdminSettingsController::class);
        
//         // change password
//         Route::get('/password/change', [AdminProfileController::class, 'changePassword']);
//         Route::post('/password/change', [AdminProfileController::class, 'updatePassword']);
//         Route::resource('/profile', AdminProfileController::class);
        
//         //product
//         Route::get('/product', [AdminProfileController::class, 'changePassword']);

//         #category Management
//         Route::get('/category/getcategorydata', [CategoryController::class, 'getCategoryData'])->name('category.data');
//         Route::post('/category/changeStatus', [CategoryController::class, 'changeCategoryStatus']);
//         Route::resource('/category', CategoryController::class);

//     });

    
// });

//========================================================================================================
Route::get('/clear-cache', function () {
    $exitCode = Artisan::call('config:clear');
    $exitCode = Artisan::call('cache:clear');
    $exitCode = Artisan::call('route:clear');
    $exitCode = Artisan::call('view:clear');
    return 'Successfully clear the cache from system!!'; //Return anything
});
//hotal book table and order
Route::group(array('prefix' => ADMIN_SLUG), function () {
    Route::get('/', [AdminLoginController::class, 'login']);
    Route::post('/', [AdminLoginController::class, 'doLogin']);

    Route::group(array('middleware' => 'auth.admin'), function () {
        Route::get('/dashboard', [DashBoardController::class, 'index'])->name('dashboard.index');
        Route::get('/logout', [AdminLoginController::class, 'doLogout']);
        Route::resource('/settings', AdminSettingsController::class);
        
        // change password
        Route::get('/password/change', [AdminProfileController::class, 'changePassword']);
        Route::post('/password/change', [AdminProfileController::class, 'updatePassword']);
        Route::resource('/profile', AdminProfileController::class);

        //category Management
        Route::get('/category/getcategorydata', [CategoryController::class, 'getCategoryData'])->name('category.data');
        Route::post('/category/changeStatus', [CategoryController::class, 'changeCategoryStatus']);
        Route::resource('/category', CategoryController::class);

         //Product Management
         Route::get('/product/getProductData', [ProductController::class, 'getProductData'])->name('product.data');
         Route::post('/product/changeStatus', [ProductController::class, 'changeProductStatus']); 
         Route::resource('/product', ProductController::class);

        //about Management
        Route::resource('/about', AboutController::class);

        //about Management
        Route::post('/table/changeAvability', [TableController::class, 'checkAvability']); 
        Route::resource('/table', TableController::class);

        //slider Management
         Route::resource('/slider', SliderController::class);

        //  ingredients Module
        Route::resource('/ingredientType', IngredientTypeController::class);
        Route::resource('/ingredient', IngredientController::class);
        Route::resource('/ingredientItem', IngredientItemController::class);

        

        //user Management
        Route::resource('/user', UserController::class);
        Route::post('/user/changeStatus', [UserController::class, 'changeUserStatus']); 

    });

});
//index controller
Route::get('/',[HomeController::class, 'index']);

//about us
Route::get('/about', [AboutusController::class, 'index']);

//Menu
Route::get('/menu', [MenuController::class, 'index']);
Route::get('/menu', [MenuController::class, 'item']);

//user authentication
Route::get('/login', [LoginController::class, 'login']);
Route::post('/login', [LoginController::class, 'doLogin']);
Route::get('/logout', [LoginController::class, 'doLogout']);

Route::get('/signup', [SignupController::class, 'registration']);
Route::post('/signup', [SignupController::class, 'registrationUser']);

// bookin table
Route::get('/bookTable', [BookingController::class, 'index']);
Route::post('/bookTable', [BookingController::class, 'bookingTable']);
Route::get('/changeTable', [BookingController::class, 'changeTable']);

Route::get('/foodDetails/{id}', function () {
    return view('niceadmin.frontend.foodDetails');
});

// checkout
Route::get('/checkout', [CheckoutController::class, 'index'])->name('checkout');
Route::post('/checkout', [CheckoutController::class, 'insert'])->name('checkout.insert');

// instamojo payment
Route::get('instamojo', [InstamojoController::class, 'instamojo'])->name('instamojo');
Route::any('callback', [InstamojoController::class, 'callback'])->name('callback');
Route::get('success', [InstamojoController::class, 'success'])->name('success');
Route::get('cancel', [InstamojoController::class, 'cancel'])->name('cancel');


// Route::get('/payment', function () {
//     return view('niceadmin.frontend.payment');
// });
// add to cart
Route::post('cart/add', [CartController::class, 'addToCart'])->name('cart.add');
Route::get('/cart/count', [CartController::class, 'getCartCount'])->name('cart.count');
Route::get('/cart', [CartController::class, 'show'])->name('cart.view');
Route::post('/updateQuantity', [CartController::class, 'updateQuantity'])->name('cart.updateQuantity');
Route::post('/updatePrice', [CartController::class, 'updatePrice'])->name('cart.updatePrice');

Route::get('/cart/remove/{key}', [CartController::class, 'remove'])->name('cart.remove');

//about image path
defined('ABOUT_IMAGE_PATH') or define('ABOUT_IMAGE_PATH', base_path() . '/public/about_img/');
defined('ABOUT_IMAGE_ROOT') or define('ABOUT_IMAGE_ROOT', URL('about_img/') . '/');

//slider image path
defined('SLIDER_IMAGE_PATH') or define('SLIDER_IMAGE_PATH', base_path() . '/public/slider_img/');
defined('SLIDER_IMAGE_ROOT') or define('SLIDER_IMAGE_ROOT', URL('slider_img/') . '/');

//slider image path
defined('INGREDIENT_IMAGE_PATH') or define('INGREDIENT_IMAGE_PATH', base_path() . '/public/ingredient_img/');
defined('INGREDIENT_IMAGE_ROOT') or define('INGREDIENT_IMAGE_ROOT', URL('ingredient_img/') . '/');

//product image path
defined('PRODUCT_IMAGE_PATH') or define('PRODUCT_IMAGE_PATH', base_path() . '/public/product_img/');
defined('PRODUCT_IMAGE_ROOT') or define('PRODUCT_IMAGE_ROOT', URL('product_img/') . '/');
