-- phpMyAdmin SQL Dump
-- version 5.2.1-1.fc36.remi
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 29, 2024 at 01:13 PM
-- Server version: 10.5.18-MariaDB
-- PHP Version: 8.1.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `man_demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `about_us`
--

CREATE TABLE `about_us` (
  `id` int(10) NOT NULL,
  `title` varchar(91) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `about_us`
--

INSERT INTO `about_us` (`id`, `title`, `description`, `image`, `created_at`, `updated_at`) VALUES
(2, 'We Are Feane', 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All', '2.png', '2024-02-27 01:07:23', '2024-02-27 01:12:08');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `role` varchar(91) NOT NULL DEFAULT 'staff',
  `name` varchar(255) NOT NULL,
  `username` varchar(91) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `is_loc` tinyint(4) NOT NULL DEFAULT 0,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `last_login_time` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `role`, `name`, `username`, `email`, `password`, `is_loc`, `status`, `last_login_time`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'payalvasoya', 'payal', 'payal@gmail.com', '$2y$12$XTAXzDqMZfSM.DMLP//ore3j4zuoo41IdcbpWRSWy7WIeQ9aadTXi', 0, 1, '2024-03-18 10:18:15', NULL, '2024-01-31 12:05:38', '2024-03-18 04:48:15');

-- --------------------------------------------------------

--
-- Table structure for table `billing_addresses`
--

CREATE TABLE `billing_addresses` (
  `id` int(11) NOT NULL,
  `order_master_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `billing_addresses`
--

INSERT INTO `billing_addresses` (`id`, `order_master_id`, `user_id`, `name`, `email`, `contact_number`, `address`, `created_at`, `updated_at`) VALUES
(1, 5, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-27 05:56:25', '2024-03-27 05:56:25'),
(2, 6, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-27 07:08:16', '2024-03-27 07:08:16'),
(3, 7, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-28 07:17:03', '2024-03-28 07:17:03'),
(4, 8, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 00:46:11', '2024-03-29 00:46:11'),
(5, 9, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 01:24:46', '2024-03-29 01:24:46'),
(6, 10, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 01:37:33', '2024-03-29 01:37:33'),
(7, 11, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 01:38:49', '2024-03-29 01:38:49'),
(8, 12, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 01:41:20', '2024-03-29 01:41:20'),
(9, 13, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 01:44:00', '2024-03-29 01:44:00'),
(10, 14, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 01:48:15', '2024-03-29 01:48:15'),
(11, 15, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 02:09:53', '2024-03-29 02:09:53'),
(12, 16, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 02:12:47', '2024-03-29 02:12:47'),
(13, 17, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 04:02:39', '2024-03-29 04:02:39'),
(14, 18, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 04:45:28', '2024-03-29 04:45:28'),
(15, 19, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 04:45:46', '2024-03-29 04:45:46'),
(16, 20, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 04:47:51', '2024-03-29 04:47:51'),
(17, 21, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 04:59:18', '2024-03-29 04:59:18'),
(18, 22, 1, 'gopi', 'gopi@gmail.com', '1254895', 'balaji hall rajkot', '2024-03-29 05:07:57', '2024-03-29 05:07:57'),
(19, 23, 1, 'gopi', 'gopi@gmail.com', '1254895', 'balaji hall rajkot', '2024-03-29 05:08:31', '2024-03-29 05:08:31'),
(20, 24, 1, 'gopi', 'gopi@gmail.com', '1254895', 'balaji hall rajkoty', '2024-03-29 05:08:42', '2024-03-29 05:08:42'),
(21, 25, 1, 'gopi', 'gopi@gmail.com', '1254895', 'balaji hall rajkot', '2024-03-29 05:13:56', '2024-03-29 05:13:56'),
(22, 26, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 05:37:07', '2024-03-29 05:37:07'),
(23, 27, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 05:44:20', '2024-03-29 05:44:20'),
(24, 28, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 05:54:06', '2024-03-29 05:54:06'),
(25, 29, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 06:33:08', '2024-03-29 06:33:08'),
(26, 30, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 06:33:35', '2024-03-29 06:33:35'),
(27, 31, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 06:35:34', '2024-03-29 06:35:34'),
(28, 32, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 06:36:35', '2024-03-29 06:36:35'),
(29, 33, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 06:36:37', '2024-03-29 06:36:37'),
(30, 34, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 06:36:38', '2024-03-29 06:36:38'),
(31, 35, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 06:36:44', '2024-03-29 06:36:44'),
(32, 36, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 06:37:25', '2024-03-29 06:37:25'),
(33, 37, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 06:38:04', '2024-03-29 06:38:04'),
(34, 38, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 06:50:28', '2024-03-29 06:50:28'),
(35, 39, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 06:51:39', '2024-03-29 06:51:39'),
(36, 40, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 06:55:56', '2024-03-29 06:55:56'),
(37, 41, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 07:04:29', '2024-03-29 07:04:29'),
(38, 42, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 07:04:48', '2024-03-29 07:04:48'),
(39, 43, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 07:05:05', '2024-03-29 07:05:05'),
(40, 44, 3, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 07:05:34', '2024-03-29 07:05:34');

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `id` int(10) NOT NULL,
  `product_id` int(10) DEFAULT NULL,
  `user_id` varchar(91) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `carts`
--

INSERT INTO `carts` (`id`, `product_id`, `user_id`, `quantity`, `created_at`, `updated_at`) VALUES
(1, NULL, NULL, 1, '2024-03-27 00:44:50', '2024-03-27 00:44:50'),
(2, NULL, NULL, 1, '2024-03-27 00:45:44', '2024-03-27 00:45:44'),
(3, NULL, NULL, 1, '2024-03-27 00:45:59', '2024-03-27 00:45:59'),
(4, NULL, NULL, 1, '2024-03-27 00:46:00', '2024-03-27 00:46:00'),
(5, NULL, NULL, 1, '2024-03-27 00:46:00', '2024-03-27 00:46:00'),
(6, NULL, NULL, 1, '2024-03-27 00:46:01', '2024-03-27 00:46:01'),
(7, NULL, NULL, 1, '2024-03-27 00:46:43', '2024-03-27 00:46:43');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `cat_name` varchar(91) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `cat_name`, `status`, `created_at`, `updated_at`) VALUES
(1, 'burger', 1, '2024-02-28 23:31:57', '2024-03-07 04:11:31'),
(2, 'pizza', 1, '2024-02-28 23:32:45', '2024-02-28 23:32:45'),
(3, 'pasta', 1, '2024-02-28 23:32:56', '2024-03-08 04:50:06'),
(4, 'fries', 1, '2024-02-28 23:33:05', '2024-03-07 04:11:33'),
(5, 'vadapav', 1, '2024-03-07 04:14:53', '2024-03-07 04:14:53');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ingredients`
--

CREATE TABLE `ingredients` (
  `id` int(10) NOT NULL,
  `name` varchar(91) NOT NULL,
  `ingredient_type_id` int(10) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ingredients`
--

INSERT INTO `ingredients` (`id`, `name`, `ingredient_type_id`, `image`, `description`, `created_at`, `updated_at`) VALUES
(3, 'tomato', 1, '3.png', 'Red,juicy fruit used in  salads', '2024-03-09 04:58:37', '2024-03-08 23:28:37'),
(4, 'chicken', 2, '4.jpg', 'Poultry meat', '2024-03-08 12:46:05', '2024-03-08 07:16:05'),
(5, 'potetos', 1, '5ingredientImg.jpg', 'demo ingredients.', '2024-03-08 12:02:40', '2024-03-08 06:32:40');

-- --------------------------------------------------------

--
-- Table structure for table `ingredients_items`
--

CREATE TABLE `ingredients_items` (
  `id` int(10) NOT NULL,
  `product_id` int(11) NOT NULL,
  `ingredient_id` int(11) NOT NULL,
  `qunatity` int(11) DEFAULT NULL,
  `weight` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ingredients_items`
--

INSERT INTO `ingredients_items` (`id`, `product_id`, `ingredient_id`, `qunatity`, `weight`, `notes`, `created_at`, `updated_at`) VALUES
(1, 89, 3, 1, 1, 'DeliciousBurger', '2024-03-15 00:08:23', '2024-03-15 00:08:23'),
(2, 98, 3, 1, 1, 'usetomato', '2024-03-15 00:17:03', '2024-03-15 00:17:03');

-- --------------------------------------------------------

--
-- Table structure for table `ingredients_types`
--

CREATE TABLE `ingredients_types` (
  `id` int(10) NOT NULL,
  `name` varchar(91) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ingredients_types`
--

INSERT INTO `ingredients_types` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'vegetable', 'A vegetable is the edible portion of a plant.', '2024-03-07 11:34:32', '2024-03-07 11:34:32'),
(2, 'protein', 'What is protein? Protein is a nutrient your body needs to grow and repair cells, and to work properly. ', '2024-03-07 11:34:32', '2024-03-07 11:34:32'),
(4, 'type3', 'demo type 3', '2024-03-08 07:16:56', '2024-03-08 23:27:14'),
(6, 'type4', 'demo type 4', '2024-03-08 23:27:57', '2024-03-08 23:27:57');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2024_01_17_071620_create_categories_table', 2),
(6, '2024_01_17_071642_create_products_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` int(11) NOT NULL,
  `order_master_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_price` int(11) NOT NULL,
  `product_quantity` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`id`, `order_master_id`, `product_id`, `product_price`, `product_quantity`, `total`, `created_at`, `updated_at`) VALUES
(1, 1, 89, 150, 1, 150, '2024-03-27 05:53:28', '2024-03-27 05:53:28'),
(2, 2, 89, 150, 1, 150, '2024-03-27 05:55:05', '2024-03-27 05:55:05'),
(3, 3, 89, 150, 1, 150, '2024-03-27 05:55:36', '2024-03-27 05:55:36'),
(4, 4, 89, 150, 1, 150, '2024-03-27 05:56:14', '2024-03-27 05:56:14'),
(5, 5, 89, 150, 1, 150, '2024-03-27 05:56:25', '2024-03-27 05:56:25'),
(6, 6, 89, 150, 1, 150, '2024-03-27 07:08:16', '2024-03-27 07:08:16'),
(7, 7, 89, 150, 1, 150, '2024-03-28 07:17:03', '2024-03-28 07:17:03'),
(8, 8, 92, 270, 1, 270, '2024-03-29 00:46:11', '2024-03-29 00:46:11'),
(9, 9, 92, 270, 1, 270, '2024-03-29 01:24:46', '2024-03-29 01:24:46'),
(10, 10, 92, 270, 1, 270, '2024-03-29 01:37:33', '2024-03-29 01:37:33'),
(11, 11, 92, 270, 1, 270, '2024-03-29 01:38:49', '2024-03-29 01:38:49'),
(12, 12, 89, 150, 1, 150, '2024-03-29 01:41:20', '2024-03-29 01:41:20'),
(13, 13, 89, 150, 1, 150, '2024-03-29 01:44:00', '2024-03-29 01:44:00'),
(14, 14, 89, 150, 1, 150, '2024-03-29 01:48:15', '2024-03-29 01:48:15'),
(15, 15, 89, 150, 1, 150, '2024-03-29 02:09:53', '2024-03-29 02:09:53'),
(16, 16, 89, 150, 1, 150, '2024-03-29 02:12:47', '2024-03-29 02:12:47'),
(17, 17, 89, 150, 1, 150, '2024-03-29 04:02:39', '2024-03-29 04:02:39'),
(18, 18, 89, 150, 1, 150, '2024-03-29 04:45:28', '2024-03-29 04:45:28'),
(19, 18, 90, 200, 1, 200, '2024-03-29 04:45:28', '2024-03-29 04:45:28'),
(20, 19, 89, 150, 1, 150, '2024-03-29 04:45:46', '2024-03-29 04:45:46'),
(21, 19, 90, 200, 1, 200, '2024-03-29 04:45:46', '2024-03-29 04:45:46'),
(22, 20, 89, 150, 1, 150, '2024-03-29 04:47:51', '2024-03-29 04:47:51'),
(23, 20, 90, 200, 1, 200, '2024-03-29 04:47:51', '2024-03-29 04:47:51'),
(24, 21, 89, 150, 1, 150, '2024-03-29 04:59:18', '2024-03-29 04:59:18'),
(25, 21, 90, 200, 1, 200, '2024-03-29 04:59:18', '2024-03-29 04:59:18'),
(26, 22, 89, 150, 1, 150, '2024-03-29 05:07:57', '2024-03-29 05:07:57'),
(27, 22, 90, 200, 1, 200, '2024-03-29 05:07:57', '2024-03-29 05:07:57'),
(28, 23, 89, 150, 1, 150, '2024-03-29 05:08:31', '2024-03-29 05:08:31'),
(29, 23, 90, 200, 1, 200, '2024-03-29 05:08:31', '2024-03-29 05:08:31'),
(30, 24, 89, 150, 1, 150, '2024-03-29 05:08:42', '2024-03-29 05:08:42'),
(31, 24, 90, 200, 1, 200, '2024-03-29 05:08:42', '2024-03-29 05:08:42'),
(32, 25, 89, 150, 1, 150, '2024-03-29 05:13:56', '2024-03-29 05:13:56'),
(33, 25, 90, 200, 1, 200, '2024-03-29 05:13:56', '2024-03-29 05:13:56'),
(34, 26, 89, 150, 1, 150, '2024-03-29 05:37:07', '2024-03-29 05:37:07'),
(35, 26, 90, 200, 1, 200, '2024-03-29 05:37:07', '2024-03-29 05:37:07'),
(36, 27, 89, 150, 1, 150, '2024-03-29 05:44:20', '2024-03-29 05:44:20'),
(37, 27, 90, 200, 1, 200, '2024-03-29 05:44:20', '2024-03-29 05:44:20'),
(38, 28, 93, 100, 1, 100, '2024-03-29 05:54:06', '2024-03-29 05:54:06'),
(39, 28, 90, 200, 1, 200, '2024-03-29 05:54:06', '2024-03-29 05:54:06'),
(40, 28, 89, 300, 2, 600, '2024-03-29 05:54:06', '2024-03-29 05:54:06'),
(41, 29, 89, 150, 1, 150, '2024-03-29 06:33:08', '2024-03-29 06:33:08'),
(42, 29, 90, 200, 1, 200, '2024-03-29 06:33:08', '2024-03-29 06:33:08'),
(43, 30, 89, 150, 1, 150, '2024-03-29 06:33:35', '2024-03-29 06:33:35'),
(44, 30, 90, 400, 2, 800, '2024-03-29 06:33:35', '2024-03-29 06:33:35'),
(45, 31, 89, 150, 1, 150, '2024-03-29 06:35:34', '2024-03-29 06:35:34'),
(46, 31, 90, 200, 1, 200, '2024-03-29 06:35:34', '2024-03-29 06:35:34'),
(47, 32, 89, 150, 1, 150, '2024-03-29 06:36:35', '2024-03-29 06:36:35'),
(48, 32, 90, 200, 1, 200, '2024-03-29 06:36:35', '2024-03-29 06:36:35'),
(49, 33, 89, 150, 1, 150, '2024-03-29 06:36:37', '2024-03-29 06:36:37'),
(50, 33, 90, 200, 1, 200, '2024-03-29 06:36:37', '2024-03-29 06:36:37'),
(51, 34, 89, 150, 1, 150, '2024-03-29 06:36:38', '2024-03-29 06:36:38'),
(52, 34, 90, 200, 1, 200, '2024-03-29 06:36:38', '2024-03-29 06:36:38'),
(53, 35, 89, 150, 1, 150, '2024-03-29 06:36:44', '2024-03-29 06:36:44'),
(54, 35, 90, 200, 1, 200, '2024-03-29 06:36:44', '2024-03-29 06:36:44'),
(55, 36, 89, 150, 1, 150, '2024-03-29 06:37:25', '2024-03-29 06:37:25'),
(56, 36, 90, 200, 1, 200, '2024-03-29 06:37:25', '2024-03-29 06:37:25'),
(57, 37, 89, 150, 1, 150, '2024-03-29 06:38:04', '2024-03-29 06:38:04'),
(58, 37, 90, 400, 2, 800, '2024-03-29 06:38:04', '2024-03-29 06:38:04'),
(59, 38, 89, 150, 1, 150, '2024-03-29 06:50:28', '2024-03-29 06:50:28'),
(60, 38, 90, 200, 1, 200, '2024-03-29 06:50:28', '2024-03-29 06:50:28'),
(61, 39, 89, 300, 2, 600, '2024-03-29 06:51:39', '2024-03-29 06:51:39'),
(62, 39, 89, 150, 1, 150, '2024-03-29 06:51:39', '2024-03-29 06:51:39'),
(63, 40, 89, 300, 2, 600, '2024-03-29 06:55:56', '2024-03-29 06:55:56'),
(64, 40, 90, 400, 2, 800, '2024-03-29 06:55:56', '2024-03-29 06:55:56'),
(65, 41, 89, 300, 2, 600, '2024-03-29 07:04:29', '2024-03-29 07:04:29'),
(66, 41, 90, 400, 2, 800, '2024-03-29 07:04:29', '2024-03-29 07:04:29'),
(67, 42, 89, 300, 2, 600, '2024-03-29 07:04:48', '2024-03-29 07:04:48'),
(68, 42, 90, 400, 2, 800, '2024-03-29 07:04:48', '2024-03-29 07:04:48'),
(69, 43, 89, 300, 2, 600, '2024-03-29 07:05:05', '2024-03-29 07:05:05'),
(70, 43, 90, 400, 2, 800, '2024-03-29 07:05:05', '2024-03-29 07:05:05'),
(71, 44, 89, 300, 2, 600, '2024-03-29 07:05:34', '2024-03-29 07:05:34'),
(72, 44, 90, 400, 2, 800, '2024-03-29 07:05:34', '2024-03-29 07:05:34');

-- --------------------------------------------------------

--
-- Table structure for table `order_masters`
--

CREATE TABLE `order_masters` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total_amount` int(11) NOT NULL COMMENT '1 => pending, 2 => packed, 3 => shipped, 4 => delivery, 5 => cancelled	',
  `order_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `order_masters`
--

INSERT INTO `order_masters` (`id`, `user_id`, `total_amount`, `order_status`, `created_at`, `updated_at`) VALUES
(1, 3, 150, 1, '2024-03-27 05:53:28', '2024-03-27 05:53:28'),
(2, 3, 150, 1, '2024-03-27 05:55:05', '2024-03-27 05:55:05'),
(3, 3, 150, 1, '2024-03-27 05:55:36', '2024-03-27 05:55:36'),
(4, 3, 150, 1, '2024-03-27 05:56:14', '2024-03-27 05:56:14'),
(5, 3, 150, 1, '2024-03-27 05:56:25', '2024-03-27 05:56:25'),
(6, 3, 150, 1, '2024-03-27 07:08:16', '2024-03-27 07:08:16'),
(7, 3, 150, 1, '2024-03-28 07:17:03', '2024-03-28 07:17:03'),
(8, 3, 270, 1, '2024-03-29 00:46:11', '2024-03-29 00:46:11'),
(9, 3, 270, 1, '2024-03-29 01:24:46', '2024-03-29 01:24:46'),
(10, 3, 270, 1, '2024-03-29 01:37:33', '2024-03-29 01:37:33'),
(11, 3, 270, 1, '2024-03-29 01:38:49', '2024-03-29 01:38:49'),
(12, 3, 150, 1, '2024-03-29 01:41:20', '2024-03-29 01:41:20'),
(13, 3, 150, 1, '2024-03-29 01:44:00', '2024-03-29 01:44:00'),
(14, 3, 150, 1, '2024-03-29 01:48:15', '2024-03-29 01:48:15'),
(15, 3, 150, 1, '2024-03-29 02:09:53', '2024-03-29 02:09:53'),
(16, 3, 150, 1, '2024-03-29 02:12:47', '2024-03-29 02:12:47'),
(17, 3, 150, 1, '2024-03-29 04:02:39', '2024-03-29 04:02:39'),
(18, 3, 350, 1, '2024-03-29 04:45:28', '2024-03-29 04:45:28'),
(19, 3, 350, 1, '2024-03-29 04:45:46', '2024-03-29 04:45:46'),
(20, 3, 350, 1, '2024-03-29 04:47:51', '2024-03-29 04:47:51'),
(21, 3, 350, 1, '2024-03-29 04:59:18', '2024-03-29 04:59:18'),
(22, 1, 350, 1, '2024-03-29 05:07:57', '2024-03-29 05:07:57'),
(23, 1, 350, 1, '2024-03-29 05:08:31', '2024-03-29 05:08:31'),
(24, 1, 350, 1, '2024-03-29 05:08:42', '2024-03-29 05:08:42'),
(25, 1, 350, 1, '2024-03-29 05:13:56', '2024-03-29 05:13:56'),
(26, 3, 350, 1, '2024-03-29 05:37:07', '2024-03-29 05:37:07'),
(27, 3, 350, 1, '2024-03-29 05:44:20', '2024-03-29 05:44:20'),
(28, 3, 900, 1, '2024-03-29 05:54:06', '2024-03-29 05:54:06'),
(29, 3, 350, 1, '2024-03-29 06:33:08', '2024-03-29 06:33:08'),
(30, 3, 950, 1, '2024-03-29 06:33:35', '2024-03-29 06:33:35'),
(31, 3, 350, 1, '2024-03-29 06:35:34', '2024-03-29 06:35:34'),
(32, 3, 350, 1, '2024-03-29 06:36:35', '2024-03-29 06:36:35'),
(33, 3, 350, 1, '2024-03-29 06:36:37', '2024-03-29 06:36:37'),
(34, 3, 350, 1, '2024-03-29 06:36:38', '2024-03-29 06:36:38'),
(35, 3, 350, 1, '2024-03-29 06:36:44', '2024-03-29 06:36:44'),
(36, 3, 350, 1, '2024-03-29 06:37:25', '2024-03-29 06:37:25'),
(37, 3, 950, 1, '2024-03-29 06:38:04', '2024-03-29 06:38:04'),
(38, 3, 350, 1, '2024-03-29 06:50:28', '2024-03-29 06:50:28'),
(39, 3, 750, 1, '2024-03-29 06:51:39', '2024-03-29 06:51:39'),
(40, 3, 1400, 1, '2024-03-29 06:55:56', '2024-03-29 06:55:56'),
(41, 3, 1400, 1, '2024-03-29 07:04:29', '2024-03-29 07:04:29'),
(42, 3, 1400, 1, '2024-03-29 07:04:47', '2024-03-29 07:04:47'),
(43, 3, 1400, 1, '2024-03-29 07:05:05', '2024-03-29 07:05:05'),
(44, 3, 1400, 1, '2024-03-29 07:05:34', '2024-03-29 07:05:34');

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_reset_tokens`
--

INSERT INTO `password_reset_tokens` (`email`, `token`, `created_at`) VALUES
('payal.svipl@gmail.com', 'GHcnKw3oPKXE2cZh4ITpRQQbunuUjA0264b6vHF16yLxyVJU2h3SBR9cAFNTre8m', '2024-01-19 06:17:17');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `payment_type` varchar(91) NOT NULL,
  `payment_id` varchar(255) NOT NULL,
  `debug_id` varchar(255) NOT NULL,
  `amount` varchar(91) NOT NULL,
  `currency` varchar(91) NOT NULL,
  `customer_name` varchar(91) NOT NULL,
  `customer_email` varchar(255) NOT NULL,
  `payment_method` varchar(255) NOT NULL,
  `payment_status` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) NOT NULL,
  `cat_id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `cat_id`, `name`, `description`, `image`, `price`, `status`, `created_at`, `updated_at`) VALUES
(89, 1, 'Delicious Burger', 'Veniam debitis quaerat officiis quasi cupiditate quo, quisquam velit, magnam voluptatem repellendus sed eaque', '89productImg.png', '150', 1, '2024-03-15 00:08:23', '2024-03-15 00:08:23'),
(90, 2, 'Delicious Pizza', 'Veniam debitis quaerat officiis quasi cupiditate quo, quisquam velit, magnam voluptatem repellendus sed eaque', '90productImg.png', '200', 1, '2024-03-15 00:09:35', '2024-03-15 00:09:35'),
(91, 3, 'Delicious Pasta', 'Veniam debitis quaerat officiis quasi cupiditate quo, quisquam velit, magnam voluptatem repellendus sed eaque', '91productImg.png', '180', 1, '2024-03-15 00:10:24', '2024-03-15 00:10:24'),
(92, 2, 'Delicious Pizza', 'Veniam debitis quaerat officiis quasi cupiditate quo, quisquam velit, magnam voluptatem repellendus sed eaque', '92productImg.png', '270', 1, '2024-03-15 00:10:59', '2024-03-15 00:10:59'),
(93, 4, 'French Fries', 'Veniam debitis quaerat officiis quasi cupiditate quo, quisquam velit, magnam voluptatem repellendus sed eaque', '93productImg.png', '100', 1, '2024-03-15 00:11:31', '2024-03-15 00:11:31'),
(94, 2, 'Delicious Pizza', 'Veniam debitis quaerat officiis quasi cupiditate quo, quisquam velit, magnam voluptatem repellendus sed eaque', '94productImg.png', '180', 1, '2024-03-15 00:12:01', '2024-03-15 00:12:01'),
(95, 1, 'Delicious Pizza', 'Veniam debitis quaerat officiis quasi cupiditate quo, quisquam velit, magnam voluptatem repellendus sed eaque', '95productImg.png', '250', 1, '2024-03-15 00:12:38', '2024-03-15 00:12:38'),
(96, 1, 'Tasty Burger', 'Veniam debitis quaerat officiis quasi cupiditate quo, quisquam velit, magnam voluptatem repellendus sed eaque', '96productImg.png', '150', 1, '2024-03-15 00:13:08', '2024-03-15 00:13:08'),
(97, 3, 'Delicious Pasta', 'Veniam debitis quaerat officiis quasi cupiditate quo, quisquam velit, magnam voluptatem repellendus sed eaque', '97productImg.png', '120', 1, '2024-03-15 00:13:41', '2024-03-15 00:13:41'),
(98, 1, 'Delicious Burger', 'Veniam debitis quaerat officiis quasi cupiditate quo, quisquam velit, magnam voluptatem repellendus sed eaque', '98productImg.png', '200', 1, '2024-03-15 00:17:03', '2024-03-15 00:17:03'),
(99, 1, 'Delicious Burger', 'Veniam debitis quaerat officiis quasi cupiditate quo, quisquam velit, magnam voluptatem repellendus sed eaque', '99productImg.png', '100', 1, '2024-03-15 00:17:52', '2024-03-15 00:17:52'),
(100, 1, 'Delicious Burger', 'Veniam debitis quaerat officiis quasi cupiditate quo, quisquam velit, magnam voluptatem repellendus sed eaque', '100productImg.jpg', '170', 1, '2024-03-15 00:18:19', '2024-03-15 00:18:19'),
(101, 2, 'Delicious Pizza', 'Veniam debitis quaerat officiis quasi cupiditate quo, quisquam velit, magnam voluptatem repellendus sed eaque', '101productImg.jpg', '270', 1, '2024-03-15 00:18:58', '2024-03-15 00:18:58'),
(102, 1, 'Delicious Pizza', 'Veniam debitis quaerat officiis quasi cupiditate quo, quisquam velit, magnam voluptatem repellendus sed eaque', '102productImg.png', '150', 1, '2024-03-15 02:04:31', '2024-03-15 02:04:31'),
(103, 1, 'Delicious Burger', 'Veniam debitis quaerat officiis quasi cupiditate quo, quisquam velit, magnam voluptatem repellendus sed eaque', '103productImg.png', '300', 1, '2024-03-15 02:05:06', '2024-03-15 02:05:06'),
(104, 1, 'Delicious Burger', 'Veniam debitis quaerat officiis quasi cupiditate quo, quisquam velit, magnam voluptatem repellendus sed eaque', '104productImg.png', '250', 1, '2024-03-15 02:05:40', '2024-03-15 02:05:40');

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `table_id` int(10) NOT NULL,
  `number_of_guests` varchar(91) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `book_date` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`id`, `user_id`, `table_id`, `number_of_guests`, `status`, `book_date`, `created_at`, `updated_at`) VALUES
(1, 3, 4, '10', 1, '2024-03-06 17:49:00', '2024-03-06 07:11:41', '2024-03-06 07:11:41'),
(2, 3, 2, '2', 1, '2024-03-06 18:17:00', '2024-03-06 07:17:39', '2024-03-06 07:17:39'),
(3, 3, 1, '2', 1, '2024-03-06 18:21:00', '2024-03-06 07:21:53', '2024-03-06 07:21:53'),
(4, 1, 2, '3', 1, '2024-03-13 18:35:00', '2024-03-06 07:35:51', '2024-03-06 07:35:51'),
(5, 1, 3, '2', 1, '2024-03-07 12:58:00', '2024-03-07 00:58:43', '2024-03-07 00:58:43'),
(6, 3, 5, '5', 1, '2024-03-07 15:14:00', '2024-03-07 04:14:03', '2024-03-07 04:14:03'),
(7, 3, 6, '5', 1, '2024-03-07 16:20:00', '2024-03-07 05:21:06', '2024-03-07 05:21:06');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(10) NOT NULL,
  `site_title` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `site_title`, `email`, `phone`, `address`, `created_at`, `updated_at`) VALUES
(1, 'Nice Admin', 'laravel@gmail.com', '4569878956', 'kalawad road rajkot.', '2024-02-10 12:18:45', '2024-02-10 06:48:45');

-- --------------------------------------------------------

--
-- Table structure for table `shipping_addresses`
--

CREATE TABLE `shipping_addresses` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_master_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `shipping_addresses`
--

INSERT INTO `shipping_addresses` (`id`, `user_id`, `order_master_id`, `name`, `email`, `contact_number`, `address`, `created_at`, `updated_at`) VALUES
(1, 3, 5, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-27 05:56:25', '2024-03-27 05:56:25'),
(2, 3, 6, 'payal', 'payal@gmail.com', '1234568795', 'balajihall rajkot', '2024-03-27 07:08:16', '2024-03-27 07:08:16'),
(3, 3, 7, 'payal', 'payal@gmail.com', '1234568795', 'balajihall rajkot', '2024-03-28 07:17:03', '2024-03-28 07:17:03'),
(4, 3, 8, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 00:46:11', '2024-03-29 00:46:11'),
(5, 3, 9, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 01:24:46', '2024-03-29 01:24:46'),
(6, 3, 10, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 01:37:33', '2024-03-29 01:37:33'),
(7, 3, 11, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 01:38:49', '2024-03-29 01:38:49'),
(8, 3, 12, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 01:41:20', '2024-03-29 01:41:20'),
(9, 3, 13, 'payal', 'payal@gmail.com', '1234568795', 'balajihall rajkot', '2024-03-29 01:44:00', '2024-03-29 01:44:00'),
(10, 3, 14, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 01:48:15', '2024-03-29 01:48:15'),
(11, 3, 15, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 02:09:53', '2024-03-29 02:09:53'),
(12, 3, 16, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 02:12:47', '2024-03-29 02:12:47'),
(13, 3, 17, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 04:02:39', '2024-03-29 04:02:39'),
(14, 3, 18, 'payal', 'payal@gmail.com', '1234568795', 'balajihall rajkot', '2024-03-29 04:45:28', '2024-03-29 04:45:28'),
(15, 3, 19, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 04:45:46', '2024-03-29 04:45:46'),
(16, 3, 20, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 04:47:51', '2024-03-29 04:47:51'),
(17, 3, 21, 'payal', 'payal@gmail.com', '1234568795', 'balajihall rajkot', '2024-03-29 04:59:18', '2024-03-29 04:59:18'),
(18, 1, 22, 'gopi', 'gopi@gmail.com', '1254895', 'balaji hall rajkot', '2024-03-29 05:07:57', '2024-03-29 05:07:57'),
(19, 1, 23, 'gopi', 'gopi@gmail.com', '1254895', 'balajihall rajkot', '2024-03-29 05:08:31', '2024-03-29 05:08:31'),
(20, 1, 24, 'gopi', 'gopi@gmail.com', '1254895', 'balajihall rajkot', '2024-03-29 05:08:42', '2024-03-29 05:08:42'),
(21, 1, 25, 'gopi', 'gopi@gmail.com', '1254895', 'fsdfdffd', '2024-03-29 05:13:56', '2024-03-29 05:13:56'),
(22, 3, 26, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 05:37:07', '2024-03-29 05:37:07'),
(23, 3, 27, 'payal', 'payal@gmail.com', '1234568795', 'balajihall rajkot', '2024-03-29 05:44:20', '2024-03-29 05:44:20'),
(24, 3, 28, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 05:54:06', '2024-03-29 05:54:06'),
(25, 3, 29, 'payal', 'payal@gmail.com', '1234568795', 'fsdfsff', '2024-03-29 06:33:08', '2024-03-29 06:33:08'),
(26, 3, 30, 'payal', 'payal@gmail.com', '1234568795', 'balajihall rajkot', '2024-03-29 06:33:35', '2024-03-29 06:33:35'),
(27, 3, 31, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 06:35:34', '2024-03-29 06:35:34'),
(28, 3, 32, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 06:36:35', '2024-03-29 06:36:35'),
(29, 3, 33, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 06:36:37', '2024-03-29 06:36:37'),
(30, 3, 34, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 06:36:38', '2024-03-29 06:36:38'),
(31, 3, 35, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 06:36:44', '2024-03-29 06:36:44'),
(32, 3, 36, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 06:37:25', '2024-03-29 06:37:25'),
(33, 3, 37, 'payal', 'payal@gmail.com', '1234568795', 'fsdfsff', '2024-03-29 06:38:04', '2024-03-29 06:38:04'),
(34, 3, 38, 'payal', 'payal@gmail.com', '1234568795', 'balajihall rajkot', '2024-03-29 06:50:28', '2024-03-29 06:50:28'),
(35, 3, 39, 'payal', 'payal@gmail.com', '1234568795', 'balajihall rajkot', '2024-03-29 06:51:39', '2024-03-29 06:51:39'),
(36, 3, 40, 'payal', 'payal@gmail.com', '1234568795', 'balajihall rajkot', '2024-03-29 06:55:56', '2024-03-29 06:55:56'),
(37, 3, 41, 'payal', 'payal@gmail.com', '1234568795', 'balajihall rajkot', '2024-03-29 07:04:29', '2024-03-29 07:04:29'),
(38, 3, 42, 'payal', 'payal@gmail.com', '1234568795', 'balaji hall rajkot', '2024-03-29 07:04:48', '2024-03-29 07:04:48'),
(39, 3, 44, 'payal', 'payal@gmail.com', '1234568795', 'balajihall rajkot', '2024-03-29 07:05:34', '2024-03-29 07:05:34');

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `id` int(11) NOT NULL,
  `title` varchar(91) NOT NULL,
  `description` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`id`, `title`, `description`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Fast Food Restaurant 1', 'Doloremque, itaque aperiam facilis rerum, commodi, temporibus sapiente ad mollitia laborum quam quisquam esse error unde. Tempora ex doloremque, labore, sunt repellat dolore, iste magni quos nihil ducimus libero ipsam.', '1.png', '2024-02-27 00:52:51', '2024-03-07 04:19:29'),
(2, 'Fast Food Restaurant 2', 'Doloremque, itaque aperiam facilis rerum, commodi, temporibus sapiente ad mollitia laborum quam quisquam esse error unde. Tempora ex doloremque, labore, sunt repellat dolore, iste magni quos nihil ducimus libero ipsam. ddddd', '2.png', '2024-02-27 01:21:19', '2024-03-07 05:22:28'),
(3, 'Fast Food Restaurant', 'Doloremque, itaque aperiam facilis rerum, commodi, temporibus sapiente ad mollitia laborum quam quisquam esse error unde. Tempora ex doloremque, labore, sunt repellat dolore, iste magni quos nihil ducimus libero ipsam.', '3.png', '2024-02-27 01:21:38', '2024-03-07 05:22:59');

-- --------------------------------------------------------

--
-- Table structure for table `tables`
--

CREATE TABLE `tables` (
  `id` int(10) NOT NULL,
  `table_number` varchar(91) NOT NULL,
  `capacity` int(11) DEFAULT NULL,
  `availability` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tables`
--

INSERT INTO `tables` (`id`, `table_number`, `capacity`, `availability`, `created_at`, `updated_at`) VALUES
(1, '101', 2, 0, '2024-02-29 07:49:40', '2024-03-06 07:21:53'),
(2, '102', 3, 0, '2024-02-29 07:49:54', '2024-03-06 07:35:51'),
(3, '103', 5, 0, '2024-02-29 07:50:01', '2024-03-07 00:58:43'),
(4, '104', 10, 0, '2024-02-29 07:50:11', '2024-03-06 07:31:18'),
(5, '105', 5, 0, '2024-02-29 07:50:39', '2024-03-07 04:14:03'),
(6, '106', 6, 0, '2024-03-01 01:31:03', '2024-03-07 05:21:06');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(91) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `contact_number` varchar(91) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `email_verified_at`, `password`, `contact_number`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'gopi', 'gopi@gmail.com', NULL, '$2y$12$dtHPOZ3lRxxpWHBlQyuAquS7rQCNSvfw088j0o1ov10/uMsm/EOJO', '1254895', 1, NULL, '2024-03-04 05:01:52', '2024-03-11 05:57:42'),
(3, 'payal', 'payal@gmail.com', NULL, '$2y$12$dtHPOZ3lRxxpWHBlQyuAquS7rQCNSvfw088j0o1ov10/uMsm/EOJO', '1234568795', 1, NULL, '2024-03-04 05:21:08', '2024-03-07 04:55:08'),
(4, 'bansi', 'bansi@gmail.com', NULL, '$2y$12$sLrHNY9aZactx8vkPh1i2..KACSaLz5zKtbE0Pqyqt82YNUg3Z1jC', '1234567895', 1, NULL, '2024-03-07 05:13:09', '2024-03-07 05:13:09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about_us`
--
ALTER TABLE `about_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `admin_email_unique` (`email`);

--
-- Indexes for table `billing_addresses`
--
ALTER TABLE `billing_addresses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `order_master_id` (`order_master_id`);

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`cat_name`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `ingredients`
--
ALTER TABLE `ingredients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ingredient_type_id` (`ingredient_type_id`);

--
-- Indexes for table `ingredients_items`
--
ALTER TABLE `ingredients_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `ingredient` (`ingredient_id`);

--
-- Indexes for table `ingredients_types`
--
ALTER TABLE `ingredients_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_master_id` (`order_master_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `order_masters`
--
ALTER TABLE `order_masters`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cat_id` (`cat_id`);

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `table_id` (`table_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shipping_addresses`
--
ALTER TABLE `shipping_addresses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tables`
--
ALTER TABLE `tables`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `table_number` (`table_number`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about_us`
--
ALTER TABLE `about_us`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `billing_addresses`
--
ALTER TABLE `billing_addresses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ingredients`
--
ALTER TABLE `ingredients`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `ingredients_items`
--
ALTER TABLE `ingredients_items`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ingredients_types`
--
ALTER TABLE `ingredients_types`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `order_masters`
--
ALTER TABLE `order_masters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `shipping_addresses`
--
ALTER TABLE `shipping_addresses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tables`
--
ALTER TABLE `tables`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ingredients`
--
ALTER TABLE `ingredients`
  ADD CONSTRAINT `ingredient_type_id` FOREIGN KEY (`ingredient_type_id`) REFERENCES `ingredients_types` (`id`);

--
-- Constraints for table `ingredients_items`
--
ALTER TABLE `ingredients_items`
  ADD CONSTRAINT `ingredient_id` FOREIGN KEY (`ingredient_id`) REFERENCES `ingredients` (`id`),
  ADD CONSTRAINT `product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `cat_id` FOREIGN KEY (`cat_id`) REFERENCES `categories` (`id`);

--
-- Constraints for table `reservations`
--
ALTER TABLE `reservations`
  ADD CONSTRAINT `table_id` FOREIGN KEY (`table_id`) REFERENCES `tables` (`id`),
  ADD CONSTRAINT `user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
