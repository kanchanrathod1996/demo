<?php

namespace App\Http\Controllers\Tadmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;
use Carbon\Carbon;
use Session;

class DashBoardController extends Controller{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request){
        return view('niceadmin.backend.dashboard');
    }
}