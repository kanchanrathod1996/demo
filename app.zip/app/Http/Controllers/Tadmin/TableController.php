<?php

namespace App\Http\Controllers\Tadmin;
use App\Http\Controllers\Controller;
use App\Models\Tadmin\Table;
use Illuminate\Http\Request;
use File;

class TableController extends Controller
{

    public function __construct() {
        
    }

    public function index() {
        $tables = Table::all(); 
        return view('niceadmin.backend.tableList',compact('tables'));
    }

    public function create() {
        return view('niceadmin.backend.table');
        
    }

    public function store(Request $request) {
        $validated = $request->validate([
            'table_number' => 'required|unique:tables',
            'capacity' => 'required', 
        ],
        $message = ['table_number.required' => 'Table Number is required']
        );
        $table = Table::create($request->all());
        $table->save();    
        return redirect()->route('table.index')->with('success_message', 'Table data added successfully!');

    }

    public function edit($id) {
        $table = Table::find($id);
        if ($table) {
            return view('niceadmin/backend/table', compact('table'));
        } else {
            return redirect('table')->with('error_message', 'Invalid table details id');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function update(Request $request, $id) {
        $data = $request->all();
        
        $validated = $request->validate([
            'table_number' => 'required',
            'capacity' => 'required', 
        ],
        $message = ['table_number.required' => 'Table Number is required']
        );

        $table = Table::findOrFail($id);

        $table->update($data);

        return redirect()->back()->with('success_message', 'table data updated successfully!');
    }

    public function show(Request $request, $id) {
        
    }
    public function destroy($id) {
        $table = Table::findOrFail($id);
        
        $table->destroy($id);
        $array = array();
        $array['success'] = true;
        $array['message'] = 'Table data deleted successfully!';
        echo json_encode($array);

    }
    public function checkAvability(Request $request) {
        $data = $request->all();
        $table = Table::find($data['id']);
        if ($table->availability) {
            $table->availability = '0';
        } else {
            $table->availability = '1';
        }
        $table->save();

        $array = array();
        $array['status'] = $table->availability;
        $array['success'] = true;
        $array['message'] = 'Status changed successfully!';
        echo json_encode($array);

    }

}