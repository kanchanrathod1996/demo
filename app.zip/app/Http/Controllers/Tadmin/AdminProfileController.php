<?php

namespace App\Http\Controllers\Tadmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Tadmin\Admin;
use Auth;
use Illuminate\Support\Facades\Hash;
use Input,
    Redirect;
use Illuminate\Support\Facades\Validator;

class AdminProfileController extends Controller
{

    protected $auth;
    
    public function __construct() {
        $this->auth = auth()->guard('admin');
    }

    public function index(){
        $admin = Admin::find($this->auth->user()->id);
        
        if ($admin) {
            return view('niceadmin.backend.profile', compact('admin'));
        } else {
            return redirect(ADMIN_SLUG)->with('error_message', 'Invalid user id');
        }
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    public function show(string $id)
    {
        //
    }


    public function edit(string $id)
    {
        //
    }

    public function update(Request $request, string $id)
    {
        $data = $request->all();
        $rules = array(
            'name' => 'required',
            'email' => 'required|email'
        );
        
        $validator = Validator::make($data, $rules);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }
        
        $admin = Admin::findOrFail($this->auth->user()->id);
        
        if($data['email'] != $admin->email){
            $admin->update($data);
            auth()->guard('admin')->logout();
            return redirect(ADMIN_SLUG)->with('success_message', 'Profile updated successfully! Please login again to start your session!');
        }else{
            $admin->update($data);
            return redirect()->back()->with('success_message', 'Profile updated successfully!');
        }
    }

    public function destroy(string $id)
    {
        //
    }

    public function changePassword() {

        return view('niceadmin.backend.changePwd');
    }

    public function updatePassword(Request $request) {
        
        $data = $request->all();
        $admin = Admin::findOrFail($this->auth->user()->id);

        if (!Hash::check($data['old_password'], $admin->password)) {
            return redirect()->back()->with('error_message', 'Incorrect old password!');
        } else {
            $rules = array(
                'password' => 'required|confirmed',
            );
            $validator = Validator::make($data, $rules);
            if ($validator->fails()) {
                return redirect()->back()->withErrors($validator)->withInput();
            }

            $admin->password = Hash::make($data['password']);
            $admin->save();
            return redirect()->back()->with('success_message', 'Password changed successfully!');
        }
    }
}
