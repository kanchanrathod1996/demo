<?php

namespace App\Http\Controllers\Tadmin;
use App\Http\Controllers\Controller;
use App\Models\Tadmin\Product;
use App\Models\Tadmin\IngredientsItem;
use App\Models\Tadmin\Ingredient;

use Illuminate\Http\Request;
use DataTables;
use File;

class IngredientItemController extends Controller
{

    public function __construct() {
        
    }

    public function index(Request $request) {
        $ingredientsItems = IngredientsItem::all(); 
        return view('niceadmin.backend.ingredientItemList',compact('ingredientsItems'));
    }

    // public function create() {
    //     $productList=Product::pluck('name','id');
    //     $ingredientList=Ingredient::pluck('name','id');
    //     return view('niceadmin.backend.ingredientItem',compact('productList','ingredientList'));        
    // }

    // public function store(Request $request) {
    //     $validated = $request->validate([
    //         'product_id' => 'required',
    //         'ingredient_id' => 'required',
    //         'qunatity' => 'required',
    //         'weight' => 'required',
    //         'notes' => 'required',
    //     ],
    //     $message = [
    //         'product_id.required' => 'Please select product',
    //         'ingredient_id.required' => 'Please select ingredient',
    //     ]
    // );
    //     $ingredientsItem = IngredientsItem::create($request->all());
    //     $ingredientsItem->save();
    
    //     return redirect()->route('ingredientsItem.index')->with('success_message', 'Ingredients Item data added successfully!');

    // }

    // public function edit($id) {
    //     $ingredientsItem = IngredientsItem::find($id);
    //     $productList=Product::pluck('name','id');
    //     $ingredientList=Ingredient::pluck('name','id');

    //     if ($ingredientsItem) {
    //         return view('niceadmin.backend.ingredientsItem', compact('ingredientsItem','productList','ingredientList'));
    //     } else {
    //         return redirect('ingredientsItem')->with('error_message', 'Invalid ingredientsItem id');
    //     }
    // }

    // /**
    //  * Update the specified resource in storage.
    //  *
    //  * @param  int  $id
    //  * @return Response
    //  */
    // public function update(Request $request, $id) {
    //     $data = $request->all();
    //     $validated = $request->validate([
    //         'cat_id' => 'required',
    //         'name' => 'required',
    //         'description' => 'required',
    //         'price' => 'required',
    //     ],
    //     $message = [
    //         'cat_id.required' => 'category field is requires',
    //     ]
    // );

    //     $product = Product::findOrFail($id);


    //     if ($request->hasFile('image')) {

    //         if ($request->file('image')->isValid()) {

    //             $oldFile = PRODUCT_IMAGE_PATH . $product->image;

    //             if (File::exists($oldFile)) {
    //                 File::delete($oldFile);
    //             }


    //             $file = $request->file('image');
    //             $ext = $file->getClientOriginalExtension();
    //             $filename = $id . '.' . $ext;
    //             $targetPath = PRODUCT_IMAGE_PATH;
    //             $imagelocation = $file->move($targetPath, $filename);
    //         } else {
    //             return redirect()->back()->withErrors($validator)->withInput();
    //         }
    //         $data['image'] = $filename;
    //     } else {
    //         $data['image'] = $product->image;
    //     }
    //     $product->update($data);

    //     return redirect()->back()->with('success_message', 'Product data updated successfully!');
    // }

    // public function show(Request $request, $id) {
        
    // }
    public function destroy($id) {
        $product = Product::findOrFail($id);
       

        $product->destroy($id);
        $array = array();
        $array['success'] = true;
        $array['message'] = 'Product data deleted successfully!';
        echo json_encode($array);
    }
    public function changeProductStatus(Request $request) {
        $data = $request->all();
        
        $product = Product::find($data['id']);
        if ($product->status) {
            $product->status = '0';
        } else {
            $product->status = '1';
        }
        $product->save();

        $array = array();
        $array['status'] = $product->status;
        $array['success'] = true;
        $array['message'] = 'Status changed successfully!';
        echo json_encode($array);
        
    }

    public function getProductData(Request $request) {
        if ($request->ajax()) {
            $data = Product::with('category')->select('*');
            return Datatables::of($data)
            ->addIndexColumn()
            ->addColumn('cat_name', function($data){
                return $data->category->cat_name;
            })
            ->addColumn('status', function($row){
                if ($row['status'] == 1) {
                    return '<a href="javascript:;" class="btn btn-success status-btn btn-sm" id="' . $row['id'] . '"><i class="bi bi-lightbulb"></i></a>';
                } else {
                    return '<a href="javascript:;" class="btn btn-danger status-btn btn-sm" id="' . $row['id'] . '"><i class="bi bi-lightbulb"></i></a>';
                }
            })
            ->addColumn('action', function($row){
       
                $btn = '<a href="product/' . $row['id'] . '/edit" class="edit btn btn-primary btn-sm">Edit</a>';
                
                $btn .= ' <a href="javascript:;" id="' . $row['id'] . '" class="btn btn-danger btn-sm delete-btn">Delete</a>';
                
                return $btn;
        })
        ->rawColumns(['action','status','image','cat_name'])
        ->make(true);
        }
    }

}