<?php

namespace App\Http\Controllers\Tadmin\user;
use App\Http\Controllers\Controller;
use App\Models\Tadmin\Category;
use App\Models\Tadmin\Product;
use Illuminate\Http\Request;

use DataTables;
use File;

class MenuController extends Controller
{

    public function __construct() {
        
    }

    public function index(Request $request) {
        $catList = Category::all(); 
        return view('niceadmin.frontend.menu',compact('catList'));
    }
    public function item(Request $request)
    {
        $catList = Category::all(); 
         // Check if a category filter is applied
         if ($request->has('category')) {
            $category = Category::where('cat_name', $request->category)->firstOrFail();
            $products = Product::where('cat_id', $category->id)->with('category')->paginate(5);
        } else {
            $products = Product::with('category')->paginate(5);
        }
        // $products = Product::with('category')->paginate(10);
        return view('niceadmin.frontend.menu', compact('catList','products'));
    }

}
