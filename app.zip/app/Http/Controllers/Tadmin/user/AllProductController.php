<?php

namespace App\Http\Controllers\Tadmin\user;
use App\Http\Controllers\Controller;
use App\Models\Tadmin\Category;
use App\Models\Tadmin\Product;
use Illuminate\Http\Request;
use DataTables;
use File;

class AllProductController extends Controller
{

    public function __construct() {
        
    }

    public function index() {
        $catList = Category::all(); 
        return view('niceadmin.frontend.menu',compact('catList'));
    }

}