<?php

namespace App\Http\Controllers\Tadmin\user;
use App\Http\Controllers\Controller;
use App\Models\Tadmin\Category;
use App\Models\Tadmin\Product;
use Illuminate\Http\Request;
use DataTables;
use File;
use Session;

// class ItemController extends Controller
class CartController extends Controller
{

    public function __construct() {
        
    }

    // public function index()
    // {
    //     // Fetch all products
    //     $products = Product::all();

    //     // Fetch all categories (assuming you have a category column in your products table)
    //     $categories = Product::distinct('category')->pluck('cat_id');

    //     return view('products.index', compact('products', 'categories'));
    // }

    public function getCartCount(Request $request)
    {
        $cart = $request->session()->get('cart', []);
        $cartCount = count($cart);
        
        return response()->json(['cart_count' => $cartCount]);
    }
        public function show(Request $request)
        {
            $cart = $request->session()->get('cart', []);
            $total= 0;
            foreach($cart as $k=>$item){
                $total += intval($item['price']);
                // $cart[$k]['total'] = $total;
                // dd($item);
            }
            foreach ($cart as $k => $item) {
                $cart[$k]['total'] = $total;
            }

            session()->put('cart', $cart);
            // dd($cart);

        return view('niceadmin.frontend.viewCart',compact('cart','total'));
        }

    
    public function addToCart(Request $request)
    {
        $product = $request->input('product');

        $productId = $product['id'];

        $cart = $request->session()->get('cart', []);
        // $cart = session()->get('cart');

        // Check if the product already exists in the cart
        $found = false;
        foreach ($cart as &$item) {
            if ($item['id'] == $productId) {
                // Product already exists in the cart, update quantity
                $item['quantity'] += 1;
                $found = true;
                break;
            }
        }

        // If the product is not found in the cart, add it with quantity 1
        if (!$found) {
            $product['quantity'] = 1;
            $cart[] = $product;
        }

        // Update the session with the modified cart
        $request->session()->put('cart', $cart);

        return response()->json(['message' => 'Product added to cart successfully']);
    }
    
    public function updateQuantity(Request $request)
    {
        $productId = $request->input('productId');
        $quantityChange = $request->input('quantityChange');

        $cart = $request->session()->get('cart', []);

        // Find the product in the cart
        foreach ($cart as &$item) {
            if ($item['id'] == $productId) {
                
                // Update the quantity
                $item['quantity'] = $quantityChange;
                // Ensure the quantity is not less than 1
                if ($item['quantity'] < 1) {
                    $item['quantity'] = 1;
                }
                break;
            }
        }
        // Update the session with the modified cart
        $request->session()->put('cart', $cart);
        // $total = 0;
        
        // Return the updated quantity
        return response()->json(['newQuantity' => $item['quantity']]);
    }

    public function updatePrice(Request $request)
    {
        $productId = $request->input('productId');
        $newQuentity = $request->input('newQuentity');

        // Retrieve the product from the database
        $product = Product::findOrFail($productId);
        $newTotalPrice = $product->price * $newQuentity;
        // $total = 0;
        $cart = $request->session()->get('cart', []);
        foreach ($cart as &$item) {
            if ($item['id'] == $productId) {
                $item['quantity'] = $newQuentity;
                $item['price'] = $newTotalPrice;
                // $total += $item['price'];
                // Ensure the quantity is not less than 1
                if ($item['quantity'] < 1) {
                    $item['quantity'] = 1;
                }
                break;
            }
        }
        $request->session()->put('cart', $cart);

        // Return the updated total price
        // return response()->json(['newTotalPrice' => $newTotalPrice,'total'=>$total]);

        return response()->json(['newTotalPrice' => $newTotalPrice]);
    }

    


    public function remove($key) {
        // $productId = $request->input('productId');
        
        // Remove the item with $productId from the cart session

        Session::forget('cart.' . $key);

        return redirect('/cart');
    
        
    }


}