<?php

namespace App\Http\Controllers\Tadmin\user;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use App\Models\Tadmin\User;
use Illuminate\Support\Facades\Auth;
use Hash;
use Session;

use Illuminate\Http\Request;

class LoginController extends Controller
{
    //Login
    public function login()
    {
        return view('niceadmin.frontend.signin');
    }
    public function doLogin(Request $request){
        $input = $request->all();
        $validated = $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ], 
        );
        $credentials = array(
            'email' => $input['email'],
            'password' => $input['password'],           
        );
        if (auth()->guard('client')->attempt($credentials)) {
            // Authentication passed...
            // session(['CLIENT_ID' => auth()->guard('client')->user()->id]);
            // session(['CLIENT_NAME' => auth()->guard('client')->user()->name]);
            $user = auth()->guard('client')->user();
            // Store user data in the session
            session(['user' => $user]);
            return redirect()->intended('/'); // Redirect to a dashboard page after successful login
        } else {
            return redirect()->back()->with('error_message', 'Sorry, unrecognized username or password.')->withInput();
        }

    }
    public function doLogout() {
        
        auth()->guard('client')->logout();
        session()->flush();
        session()->regenerate();

        return redirect('/login')->with('success_message', 'You are successfully logged out.');
    }
    
}
