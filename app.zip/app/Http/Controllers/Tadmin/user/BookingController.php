<?php

namespace App\Http\Controllers\Tadmin\user;
use App\Http\Controllers\Controller;
use App\Models\Tadmin\User;
use App\Models\Tadmin\Table;
use App\Models\Tadmin\Booking;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Hash;
use Session;

class BookingController extends Controller
{
    public function index(Request $request) {
         
        //dd(Auth::guard('client')->check());
        //dd(auth()->guard('client')->user());
        if(Auth::guard('client')->check()){
            $tables = Table::all();
            return view('niceadmin.frontend.bookTable',compact('tables'));
        }else{
            return redirect('/login')->with('error_message', 'Please log in before booking a table.')->withInput();
        }
    }
    public function changeTable(Request $request) {
        $data = $request->all();
        $capacity = $data['capacity'];
        $tables = Table::where('capacity', '>=', $capacity)
                       ->where('availability', 1)
                       ->distinct()
                       ->get(['id', 'table_number']);

        if ($tables->isEmpty()) {
            return response()->json(['message' => 'No tables available.']);
        }                       
                       
        return response()->json(['tables' => $tables]);
    }
    public function bookingTable(Request $request) {
        $data = $request->all();
        // dd($data);
        // Validate the form data
        $validatedData = $request->validate([
            'number_of_guests' => 'required|numeric',
            'table_id' => 'required|exists:tables,id',
            'book_date' => 'required|date'
            // Add validation rules for other fields as needed
        ]);
        $user_id=Auth::guard('client')->user()->id;
        $data['user_id']=$user_id;
        $data['book_date']=date('Y-m-d H:i:s',strtotime($data['book_date']));

        // @dd($data);
        Booking::create($data);
        $table=Table::find($data['table_id']);
        $table->availability=0;
        $table->update();
        return redirect('/')->with('success_message', 'Table booked successfully!');
        
    }

}
