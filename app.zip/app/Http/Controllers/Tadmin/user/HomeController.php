<?php

namespace App\Http\Controllers\Tadmin\user;
use App\Http\Controllers\Controller;
use App\Models\Tadmin\About;
use App\Models\Tadmin\Category;
use App\Models\Tadmin\Product;
use App\Models\Tadmin\Slider;
use Illuminate\Http\Request;
use DataTables;
use File;

class HomeController extends Controller
{

    public function __construct() {
        
    }
    // index page
    public function index(Request $request) {
        $abouts = About::first(); 
        $slides = Slider::all(); 
        $catList = Category::all(); 
        $products = Product::with('category')->paginate(10);
        return view('niceadmin.frontend.index',compact('abouts','slides','catList','products'));
    }
    // //about data
    // public function aboutUs(Request $request) {
    //     $abouts = About::first(); 
    //     return view('niceadmin.frontend.index',compact('abouts'));
    // }

    // public function slider(Request $request) {
    //     $slide = Slider::first(); 
    //     return view('niceadmin.frontend.index',compact('slide'));
    // }


}