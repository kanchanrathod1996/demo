<?php

namespace App\Http\Controllers\Tadmin\user;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\Tadmin\User;


class SignupController extends Controller
{
    //Registration
    public function registration()
    {
        return view('niceadmin.frontend.signup');
    }

    public function registrationUser(Request $request)
    {
        $data = $request->all();
        $validated = $request->validate([
            'username' => 'required',
            'email' => 'required|email|unique:users',
            'password' => 'required',
            'contact_number' =>'required',
            'confirm_password' => 'required_with:password|same:password',
        ],  

        $message = [
            'email.unique' => 'This user already exist',
        ]
    );
        $data['password'] = Hash::make($data['password']);
        User::create($data);
        return redirect('/login')->with('success_message', 'User added successfully!');

    }

}
