<?php

namespace App\Http\Controllers\Tadmin\user;
use App\Http\Controllers\Controller;
use App\Models\Tadmin\Category;
use App\Models\Tadmin\Product;
use App\Models\Tadmin\Payment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use DataTables;
use File;
use Session;
use Exception;



class InstamojoController extends Controller
{

    public function instamojo(Request $request)
    {
        if(env('INSTAMOJO_ENVIRONMENT') == 'sandbox'){
            $url = "https://test.instamojo.com/api/1.1/payment-requests/";
        }else{
            $url = "https://www.instamojo.com/api/1.1/payment-requests/";
        }
        $api_key = env('INSTAMOJO_API_KEY');
        $auth_token = env('INSTAMOJO_AUTH_TOKEN');
        $ch = curl_init();
        
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt($ch, CURLOPT_HTTPHEADER,
        array("X-Api-Key:$api_key","X-Auth-Token:$auth_token"));
        $cart = $request->session()->get('cart', []);
            $total= 0;
            foreach($cart as $k=>$item){
                $total += intval($item['price']);
                // $cart[$k]['total'] = $total;
                // dd($item);
            }
            foreach ($cart as $k => $item) {
                $cart[$k]['total'] = $total;
            }
            // dd($total);
            // dd(auth()->guard('client')->user()->username);
            $redirect_url = "http://example.com/callback";
            // $redirect_url = 'http://man.demo.svs151/callback';
                $payload = Array(
                    'purpose' => env('APP_NAME'),
                    'amount' => $total,
                    'phone' => auth()->guard('client')->user()->contact_number,
                    'buyer_name' => auth()->guard('client')->user()->username,
                    'redirect_url' => $redirect_url,
                    'send_email' => true,
                    'send_sms' => true,
                    'email' => 'payal.svipl@gmail.com',
                    'webhook' => 'http://www.example.com/webhook/',
                    'allow_repeated_payments' => false
                );
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($payload));
                $response = curl_exec($ch);
                // dd($response);
                curl_close($ch); 
                $response = json_decode($response,true);
                // dd($response);
                // dd($response);
                if($response['success'] === true){
                    return redirect($response['payment_request']['longurl']);
                }else{
                    return redirect()->route('cancel');
                }
    }

    public function cancel()
    {
        return "payment is cancle";
    }

    public function success(Request $request)
    {
        return "payment is success";
    }


}