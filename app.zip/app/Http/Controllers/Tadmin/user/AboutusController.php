<?php

namespace App\Http\Controllers\Tadmin\user;
use App\Http\Controllers\Controller;
use App\Models\Tadmin\About;
use Illuminate\Http\Request;
use DataTables;
use File;

class AboutusController extends Controller
{

    public function __construct() {
        
    }

    public function index() {
        $abouts = About::first(); 
        return view('niceadmin.frontend.about',compact('abouts'));
    }

}