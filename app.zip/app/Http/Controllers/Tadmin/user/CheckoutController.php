<?php

namespace App\Http\Controllers\Tadmin\user;
use App\Http\Controllers\Controller;
use App\Models\Tadmin\About;
use App\Models\Tadmin\Category;
use App\Models\Tadmin\Product;
use App\Models\Tadmin\BillingAddress;
use App\Models\Tadmin\ShippingAddress;
use App\Models\Tadmin\Slider;
use App\Models\Tadmin\OrderMaster;
use App\Models\Tadmin\OrderDetail;
use Illuminate\Http\Request;
use DataTables;
use Session;
use Illuminate\Support\Facades\Auth;
use Hash;

use File;

class CheckoutController extends Controller
{

    public function index(Request $request)
    {
        if(Auth::guard('client')->check()){
            $userId = Auth::guard('client')->user()->id; // Get the logged-in user's ID
            $cart = $request->session()->get('cart', []);
            foreach ($cart as $key => $item) {
                $cart[$key]['user_id'] = $userId;
                 //dd($cart);
            }
            //dd($cart);
            return view('niceadmin.frontend.checkOut',compact('cart'));
        }else{
            return redirect('/login')->with('error_message', 'Please log in first')->withInput();
        }
        
    }

    public function insert(Request $request)
    {  
        $request->validate([
            'username' => 'required',
            'email' => 'required',
            'contact_number' => 'required',
            'address' => 'required',
        ]);
        $user = Auth::guard('client')->user();
        $user_id = $user->id; // Assuming you want to get the user's ID

        $cart = $request->session()->get('cart', []);
        $finalTotal = 0;
        foreach ($cart as $value) {
           $name = $value['name'];
           $product_id = $value['id'];
           $product_quantity = $value['quantity'];
           $products_price = $value['price'];   
           $total = $product_quantity*$products_price;
           $finalTotal= $finalTotal + $total;
        }
            $order_master = OrderMaster::create([
            'user_id' => $user_id ,
            'total_amount' => $finalTotal,
           ]);
 
           foreach ($cart as $value) {

            $name = $value['name'];
            $product_id = $value['id'];
            $product_quantity = $value['quantity'];
            $products_price = $value['price'];   
 
            $total = $product_quantity*$products_price;
            $finalTotal= $finalTotal + $total;
         
           $order_master_id = OrderMaster::orderBy('created_at', 'desc')->first()->id;
        //    dd($order_master_id);

           $order_details = OrderDetail::create([
            'order_master_id' =>  $order_master_id,
            'product_id' => $product_id,
            'product_price' =>  $products_price,
            'product_quantity' => $product_quantity,
            'total' => $total ,
            ]); 
   
        }
        $billing_array = [
            'user_id' => $user_id,
            'order_master_id' =>  $order_master_id,
            'name' => $request->username,
            'email' => $request->email ,            
            'address' => $request->address,
            'contact_number' => $request->contact_number,
        ];
        // dd($billing_array);
        $billing =  BillingAddress::create($billing_array);

        if(isset($request->same_as)){
            $shipping =  ShippingAddress::create($billing_array);
        } else {
            $shipping =  ShippingAddress::create(['user_id' => $user_id,
        'order_master_id' =>  $order_master_id,
        'name' => $request->username,
        'email' => $request->email ,            
        'address' => $request->address1 ,
        'contact_number' => $request->contact_number1,
        ]);
        }
        // $cart->map->delete();
        session()->put('cart',$cart);
        $order_id = OrderMaster::where('user_id',$user_id)->orderBy('created_at', 'desc')->first()->id;
        session()->put('order_id', $order_id);

        $payment = $request->payment;
        // dd($payment);

        if($payment == 'instamojo'){
            return redirect('instamojo');
        }elseif($payment == 'stripe'){
            return redirect('/payment');
        }else{
            return redirect('/checkout')->with('error_message','please check atleast one payment method');
        }
        
        // return redirect('/checkout')->with('error_message');
     
    }

}