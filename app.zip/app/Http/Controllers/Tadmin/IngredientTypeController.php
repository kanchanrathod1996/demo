<?php

namespace App\Http\Controllers\Tadmin;
use App\Http\Controllers\Controller;
use App\Models\Tadmin\IngredientsTypes;
use Illuminate\Http\Request;
use DataTables;
use File;

class IngredientTypeController extends Controller
{

    public function __construct() {
        
    }

    public function index() {
        $ingredient_types = IngredientsTypes::all(); 
        return view('niceadmin.backend.ingredientTypeList',compact('ingredient_types'));
    }

    public function create() {
        return view('niceadmin.backend.ingredientType');
        
    }

    public function store(Request $request) {
        $validated = $request->validate([
            'name' => 'required',
            'description' => 'required', 
        ]);
        $ingredient_type = IngredientsTypes::create($request->all());
        $ingredient_type->save();
        return redirect()->route('ingredientType.index')->with('success_message', 'Ingredient Type data added successfully!');

    }

    public function edit($id) {
        $ingredient_type = IngredientsTypes::find($id);
        if ($ingredient_type) {
            return view('niceadmin.backend.ingredientType', compact('ingredient_type'));
        } else {
            return redirect('ingredientType')->with('error_message', 'Invalid Ingredient Type details id');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function update(Request $request, $id) {
        $data = $request->all();
        
        $validated = $request->validate([
            'name' => 'required',
            'description' => 'required', 
        ]);

        $ingredient_type = IngredientsTypes::findOrFail($id);
        $ingredient_type->update($data);

        return redirect()->back()->with('success_message', 'Ingredient Types data updated successfully!');
    }

    public function show(Request $request, $id) {
        
    }
    public function destroy($id) {
        $ingredient_type = IngredientsTypes::findOrFail($id);

      
        IngredientsTypes::destroy($id);


        $ingredient_type->destroy($id);
        $array = array();
        $array['success'] = true;
        $array['message'] = 'Ingredient Types data deleted successfully!';
        echo json_encode($array);

    }

}