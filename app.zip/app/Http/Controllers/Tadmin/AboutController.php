<?php

namespace App\Http\Controllers\Tadmin;
use App\Http\Controllers\Controller;
use App\Models\Tadmin\About;
use Illuminate\Http\Request;
use DataTables;
use File;

class AboutController extends Controller
{

    public function __construct() {
        
    }

    public function index() {
        $abouts = About::all(); 
        return view('niceadmin.backend.aboutList',compact('abouts'));
    }

    public function create() {
        return view('niceadmin.backend.about');
        
    }

    public function store(Request $request) {
        $validated = $request->validate([
            'title' => 'required',
            'description' => 'required',
            'image' => 'required'
 
        ]);
        $about = About::create($request->all());

        if(isset($about['image'])){
            if ($request->file('image')->isValid()) {
                $file = $request->file('image');
                $ext = $file->getClientOriginalExtension();
                $filename = $about->id.'aboutImg'.'.' . $ext;
                $targetPath = ABOUT_IMAGE_PATH;
                $imagelocation = $file->move($targetPath, $filename);
            } else {
                return redirect()->back()->with("error_message","data not inserted");
            }
            $about->image = $filename;
            $about->save();
        }
    
        return redirect()->route('about.index')->with('success_message', 'About data added successfully!');

    }

    public function edit($id) {
        $about = About::find($id);
        if ($about) {
            return view('niceadmin/backend/about', compact('about'));
        } else {
            return redirect('about')->with('error_message', 'Invalid about details id');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function update(Request $request, $id) {
        $data = $request->all();
        
        $validated = $request->validate([
            'title' => 'required',
            'description' => 'required', 
        ]);

        $about = About::findOrFail($id);


        if ($request->hasFile('image')) {

            if ($request->file('image')->isValid()) {

                $oldFile = ABOUT_IMAGE_PATH . $about->image;

                if (File::exists($oldFile)) {
                    File::delete($oldFile);
                }


                $file = $request->file('image');
                $ext = $file->getClientOriginalExtension();
                $filename = $id . '.' . $ext;
                $targetPath = ABOUT_IMAGE_PATH;
                $imagelocation = $file->move($targetPath, $filename);
            } else {
                return redirect()->back()->withErrors($validator)->withInput();
            }
            $data['image'] = $filename;
        } else {
            $data['image'] = $about->image;
        }
        $about->update($data);

        return redirect()->back()->with('success_message', 'About data updated successfully!');
    }

    public function show(Request $request, $id) {
        
    }
    public function destroy($id) {
        $about = About::findOrFail($id);
        $oldFile = ABOUT_IMAGE_PATH . $about->image;

        if (File::exists($oldFile)) {
            File::delete($oldFile);
        }

        // About::destroy($id);


        $about->destroy($id);
        $array = array();
        $array['success'] = true;
        $array['message'] = 'About us data deleted successfully!';
        echo json_encode($array);

    }

}