<?php

namespace App\Http\Controllers\Tadmin;
use App\Http\Controllers\Controller;
use App\Models\Tadmin\Slider;
use Illuminate\Http\Request;
use DataTables;
use File;

class SliderController extends Controller
{

    public function __construct() {
        
    }

    public function index() {
        $slides = Slider::all(); 
        return view('niceadmin.backend.sliderList',compact('slides'));
    }

    public function create() {
        return view('niceadmin.backend.slider');
        
    }

    public function store(Request $request) {
        $validated = $request->validate([
            'title' => 'required',
            'description' => 'required',
            'image' => 'required'
 
        ]);
        $slide = Slider::create($request->all());

        if(isset($slide['image'])){
            if ($request->file('image')->isValid()) {
                $file = $request->file('image');
                $ext = $file->getClientOriginalExtension();
                $filename = $slide->id.'sliderImg'.'.' . $ext;
                $targetPath = SLIDER_IMAGE_PATH;
                $imagelocation = $file->move($targetPath, $filename);
            } else {
                return redirect()->back()->with("error_message","data not inserted");
            }
            $slide->image = $filename;
            $slide->save();
        }
    
        return redirect()->route('slider.index')->with('success_message', 'Slider data added successfully!');

    }

    public function edit($id) {
        $slide = Slider::find($id);
        if ($slide) {
            return view('niceadmin/backend/slider', compact('slide'));
        } else {
            return redirect('slider')->with('error_message', 'Invalid slider id');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function update(Request $request, $id) {
        $data = $request->all();
        
        $validated = $request->validate([
            'title' => 'required',
            'description' => 'required', 
        ]);

        $slide = Slider::findOrFail($id);


        if ($request->hasFile('image')) {

            if ($request->file('image')->isValid()) {

                $oldFile = SLIDER_IMAGE_PATH . $slide->image;

                if (File::exists($oldFile)) {
                    File::delete($oldFile);
                }


                $file = $request->file('image');
                $ext = $file->getClientOriginalExtension();
                $filename = $id . '.' . $ext;
                $targetPath = SLIDER_IMAGE_PATH;
                $imagelocation = $file->move($targetPath, $filename);
            } else {
                return redirect()->back()->withErrors($validator)->withInput();
            }
            $data['image'] = $filename;
        } else {
            $data['image'] = $slide->image;
        }
        $slide->update($data);

        return redirect()->back()->with('success_message', 'Slider data updated successfully!');
    }

    public function show(Request $request, $id) {
        
    }
    public function destroy($id) {
        $slide = Slider::findOrFail($id);
        $oldFile = SLIDER_IMAGE_PATH . $slide->image;

        if (File::exists($oldFile)) {
            File::delete($oldFile);
        }

        $slide->destroy($id);
        $array = array();
        $array['success'] = true;
        $array['message'] = 'Slider data deleted successfully!';
        echo json_encode($array);
    }

}