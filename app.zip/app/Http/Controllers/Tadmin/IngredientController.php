<?php

namespace App\Http\Controllers\Tadmin;
use App\Http\Controllers\Controller;
use App\Models\Tadmin\Ingredient;
use App\Models\Tadmin\IngredientsTypes;
use Illuminate\Http\Request;
use DataTables;
use File;

class IngredientController extends Controller
{

    public function __construct() {
        
    }

    public function index() {
        $ingredients = Ingredient::all(); 
        return view('niceadmin.backend.ingredientList',compact('ingredients'));
    }

    public function create() {
        $IngredientsTypes=IngredientsTypes::pluck('name','id');
        return view('niceadmin.backend.ingredient',compact('IngredientsTypes'));
        
    }

    public function store(Request $request) {
        $validated = $request->validate([
            'ingredient_type_id'=>'required',
            'name' => 'required',
            'description' => 'required', 
            'image' => 'required', 
        ],
        $message = [
                    'ingredient_type_id.required'=>'plese select ingredient type ',            
                   ]
        );
        $ingredient = Ingredient::create($request->all());

        if(isset($ingredient['image'])){
            if ($request->file('image')->isValid()) {
                $file = $request->file('image');
                $ext = $file->getClientOriginalExtension();
                $filename = $ingredient->id.'ingredientImg'.'.' . $ext;
                $targetPath = INGREDIENT_IMAGE_PATH;
                $imagelocation = $file->move($targetPath, $filename);
            } else {
                return redirect()->back()->with("error_message","data not inserted");
            }
            $ingredient->image = $filename;
            $ingredient->save();
        }
        return redirect()->route('ingredient.index')->with('success_message', 'Ingredients data added successfully!');

    }

    public function edit(Request $request,$id) {
        $ingredient = Ingredient::find($id);
        $IngredientsTypes=IngredientsTypes::pluck('name','id');

        if ($ingredient) {
            return view('niceadmin/backend/ingredient', compact('ingredient','IngredientsTypes'));
        } else {
            return redirect('ingredient')->with('error_message', 'Invalid ingredient id');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function update(Request $request, $id) {
        $data = $request->all();
        //@dd($data);
        $validated = $request->validate([
            'ingredient_type_id'=>'required',
            'name' => 'required',
            'description' => 'required', 
        ],
        $message = [
                    'ingredient_type_id.required'=>'plese select ingredient type ',            
                   ]
        );

        $ingredient = Ingredient::findOrFail($id);


        if ($request->hasFile('image')) {

            if ($request->file('image')->isValid()) {

                $oldFile = INGREDIENT_IMAGE_PATH . $ingredient->image;

                if (File::exists($oldFile)) {
                    File::delete($oldFile);
                }


                $file = $request->file('image');
                $ext = $file->getClientOriginalExtension();
                $filename = $id . '.' . $ext;
                $targetPath = INGREDIENT_IMAGE_PATH;
                $imagelocation = $file->move($targetPath, $filename);
            } else {
                return redirect()->back()->withErrors($validator)->withInput();
            }
            $data['image'] = $filename;
        } else {
            $data['image'] = $ingredient->image;
        }
        $ingredient->update($data);

        return redirect()->back()->with('success_message', 'Ingredient data updated successfully!');
    }


    public function show(Request $request, $id) {
        
    }
    public function destroy(Request $request,$id) {
        $ingredient = Ingredient::find($id);
        $oldFile = INGREDIENT_IMAGE_PATH . $ingredient->image;

            // Delete associated items first
        $ingredient->items()->delete();

        if (File::exists($oldFile)) {
            File::delete($oldFile);
        }

        $ingredient->destroy($id);
        $array = array();
        $array['success'] = true;
        $array['message'] = 'Ingredient data deleted successfully!';
        echo json_encode($array);
    }
   
}