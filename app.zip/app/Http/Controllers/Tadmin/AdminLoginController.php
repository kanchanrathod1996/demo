<?php

namespace App\Http\Controllers\Tadmin;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Redirect;
use Auth;
// use App\Models\Admin;
use App\Models\Tadmin\Admin;
use Illuminate\Support\Facades\DB;

class AdminLoginController extends Controller
{
    // use AuthenticatesUsers;

    /**
     * Where to redirect users after login / registration.
     *
     * @var string
     */
    protected $redirectTo = '/';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest.admin', ['except' => 'doLogout']);
    }

    public function login() {
        
        return view('niceadmin.backend.login');

    }

    public function doLogin(Request $request) {

        $input = $request->all();

        $credentials = array(
            'username' => $request->username,
            'password' => $request->password,
            'status' => '1'
        );

        if (auth()->guard('admin')->attempt($credentials)) {
            
            if(auth()->guard('admin')->user()->status == 1 && auth()->guard('admin')->user()->is_lock == 0){
                Admin::where('id', Auth()->guard('admin')->user()->id)->update(['last_login_time' => DB::raw('CURRENT_TIMESTAMP')]);
                session(['ROLE' => auth()->guard('admin')->user()->role]);
                session(['ADMIN_USER_ID' => auth()->guard('admin')->user()->id]);
                return redirect(ADMIN_SLUG.'/dashboard');
            }else if(auth()->guard('admin')->user()->status == 0){
                auth()->guard('admin')->logout();
                session()->flush();
                session()->regenerate();
                return redirect(ADMIN_SLUG)->with('error_message', 'Your accont is disabled.');
            }else if(auth()->guard('admin')->user()->is_lock == 1){
                auth()->guard('admin')->logout();
                session()->flush();
                session()->regenerate();
                return redirect(ADMIN_SLUG)->with('error_message', 'Your accont is locked.');
            }
            
        }
        // authentication failure! lets go back to the login page
        return redirect(ADMIN_SLUG)->with('error_message', 'Invalid username or password')->withInput();
    }

    public function doLogout() {
        
        Auth()->guard('admin')->logout();
        session()->flush();
        session()->regenerate();
        return redirect(ADMIN_SLUG)->with('success_message', 'You are successfully logged out.');
    }
}
