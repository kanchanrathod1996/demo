<?php

namespace App\Http\Controllers\Tadmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Tadmin\Setting;
use Input;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Redirect;
use File;
use Session;

class AdminSettingsController extends Controller
{
    
    protected $setting;

    
    public function __construct(Setting $setting) {
        
        $this->setting = $setting;
    }

    public function index()
    {
        $settings = Setting::first();
            
        if($settings){
            return redirect()->route('settings.edit',$settings->id);
        }else{
            return redirect()->route('settings.create');
        }
    }

    public function create()
    {
        $settings = Setting::first();
            
        if($settings){
            return redirect()->route('settings.edit',$settings->id);
        }else{
            return view('niceadmin.backend.settings');
        }
    }


    public function store(Request $request)
    {
        $rules = array(
            'site_title' => 'required',
        );
        $data = $request->all();
        
        $validator = Validator::make($data, $rules);
        if ($validator->fails()) {
            return Redirect()->back()->withErrors($validator)->withInput();
        }
        $setting = Setting::create($data);
        
        return redirect()->back()->with('success_message', 'Setting added successfully!');
    }


    public function show(string $id)
    {
        //
    }

    public function edit(string $id)
    {
        $setting = Setting::find($id);
        if ($setting) {
            return view('niceadmin.backend.settings', compact('setting'));
        } else {
            return redirect(ADMIN_SLUG.'settings')->with('error_message', 'Invalid setting id');
        }
    }


    public function update(Request $request, string $id)
    {
        $rules = array(
            'site_title' => 'required',
        );
        $setting = Setting::findOrFail($id);
        
        $data = $request->all();
        
        $validator = Validator::make($data, $rules);
        if ($validator->fails()) {
            return Redirect()->back()->withErrors($validator)->withInput();
        }
        
        $setting->update($data);
        
        return redirect()->back()->with('success_message', 'Setting updated successfully!');
    }

    public function destroy(string $id)
    {
        //
    }
}
