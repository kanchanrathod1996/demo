<?php

namespace App\Http\Controllers\Tadmin;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
// use App\Helpers\Tadmin\Common;
use App\Models\Tadmin\DemoCategory;
use Input;
use Illuminate\Support\Facades\Validator;
use Redirect;
use Illuminate\Support\Facades\DB;
use File;
use Session;
use Auth;
use Illuminate\Support\Str;
use DataTables;

class CategoryController extends Controller
{

    public function __construct() {
        
    }


    public function index() {
    
        return view('niceadmin.backend.categoryList');
    }

    public function create() {
        $catList = DemoCategory::pluck('cat_name','id')->toArray();
        return view('niceadmin.backend.category',compact('catList'));
    }

    public function store(Request $request) {

        $rules = array(
            'parent_id' => 'required',
            'cat_name' => 'required',
        );
        $data = $request->all();

        $validator = Validator::make($data, $rules);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        $cat = DemoCategory::create($data);

        $lastInsertId = $cat->id;
        $cat->save();
        return redirect()->route('category.index')->with('success_message', 'category added successfully!');
    }

    public function edit($id) {
        
        $cat = DemoCategory::find($id);
        $catList = DemoCategory::pluck('cat_name','id')->toArray();
        if ($cat) {
            return view('niceadmin.backend.category', compact('cat','catList'));
        } else {
            return redirect('category')->with('error_message', 'Invalid category id');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function update(Request $request, $id) {
        
        $rules = array(
            'parent_id' => 'required',
            'cat_name' => 'required',
        );

        $cat = DemoCategory::findOrFail($id);

        $data = $request->all();
        // dd($data);

        $validator = Validator::make($data, $rules);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }
        
        $cat->update($data);

        return redirect()->route('category.index')->with('success_message', 'Category updated successfully!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id) {
        
        $cat = DemoCategory::findOrFail($id);


        DemoCategory::destroy($id);

        $array = array();
        $array['success'] = true;
        $array['message'] = 'Category deleted successfully!';
        echo json_encode($array);
    }

    public function changeCategoryStatus(Request $request) {

        $data = $request->all();
        
        $cat = DemoCategory::find($data['id']);
        if ($cat->status) {
            $cat->status = '0';
        } else {
            $cat->status = '1';
        }
        $cat->save();

        $array = array();
        $array['status'] = $cat->status;
        $array['success'] = true;
        $array['message'] = 'Status changed successfully!';
        echo json_encode($array);
    }

    public function getCategoryData(Request $request) {

        if ($request->ajax()) {
            $data = DemoCategory::select('*');
            return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('parent_id', function($row){
                    if ($row['parent_id'] == '') {
                        return '-';
                    } else {
                        return $row->parentCategory->cat_name;
                    }
                })
                ->addColumn('status', function($row){
                    if ($row['status'] == 1) {
                        return '<a href="javascript:;" class="btn btn-success status-btn btn-sm" id="' . $row['id'] . '"><i class="bi bi-check-circle"></i></a>';
                    } else {
                        return '<a href="javascript:;" class="btn btn-danger status-btn btn-sm" id="' . $row['id'] . '"><i class="bi bi-exclamation-octagon"></a>';
                    }
                })
                ->addColumn('action', function($row){

                        $btn = '<a href="category/' . $row['id'] . '/edit" class="edit btn btn-primary btn-sm"><i class="bi bi-pencil"></i></a>';
                        $btn .= ' <a href="javascript:;" id="' . $row['id'] . '" class="btn btn-danger btn-sm delete-btn"><i class="bi bi-trash3"></i></a>';
                        
                        return $btn;
                })
                
                ->rawColumns(['parent_id','status','action'])
                ->make(true);
        }
          
        return view('niceadmin.backend.categoryList');
    }

}