<?php

namespace App\Http\Controllers\Student;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Student;
use Illuminate\Support\Facades\Validator;
use Hash;

class StudentLoginController extends Controller
{
    
    public function login(Request $request) {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required|min:5',
        ]);
    
        if ($validator->fails()) {
            $data = [
                "status" => 422,
                "message" => $validator->messages(),
            ];
            return response()->json($data, 422);
        }else{
    
            $student = Student::where('email', $request->email)->first();
    
            if (!$student || !Hash::check($request->password, $student->password)) {
                $data = [
                    "status" => 401,
                    "message" => 'Invalid email or password',
                ];
                return response()->json($data, 401);
            }
    
            $data = [
                "status" => 200,
                "message" => 'Student login successfully',
            ];
            return response()->json($data, 200);
        }
    }

    public function changePassword(Request $request,$id) {
        $validator = Validator::make($request->all(), [
            'old_password' => 'required|min:5',
            'new_password' => 'required|min:5',
        ]);
    
        if ($validator->fails()) {
            $data = [
                "status" => 422,
                "message" => $validator->messages(),
            ];
            return response()->json($data, 422);
        }else{
            $student = Student::find($id);

            // $student = Student::where('email', $request->email)->first();

            if (!$student || !Hash::check($request->old_password, $student->password)) {
                $data = [
                    "status" => 422,
                    "message" => 'Invalid old password',
                ];
                return response()->json($data, 422);
            }
        
            // Update the password
            $student->update(['password' => bcrypt($request->new_password)]);
        
            $data = [
                "status" => 200,
                "message" => 'Password changed successfully',
            ];
            return response()->json($data, 200);
        }
    }
    
}
