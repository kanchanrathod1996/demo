<?php

namespace App\Http\Controllers\Student;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Student;
use Illuminate\Support\Facades\Validator;


class StudentController extends Controller
{
    public function index() {
       $student = Student::all();
       $data = [
        'status'=>200,
        'student'=>$student
       ];
       return response()->json($data,200); 
    }
    public function store(Request $request) {
        
       $validator= Validator::make($request->all(),
       [
        'username'=>'required',
        'email'=>'required|email|unique:student',
        'password'=>'required|min:5',
        'confirm_password' => 'required_with:password|same:password|min:5',
        'phone'=>'required'
       ]);
       if($validator->fails()){
        $data = [
            "status"=>422,
            "message"=>$validator->messages()
        ];
            return response()->json($data,422); 
       }else{
            $student = $request->all();
            $student['password']=bcrypt($student['password']);
            Student::create($student);
            $data = [
                "status"=>200,
                "message"=>'data inserted succefully'
            ];
            return response()->json($data,200); 
       }
    }
    public function edit(Request $request,$id){
        //print_r($request->all());exit;
        $validator= Validator::make($request->all(),
        [
            'username'=>'required',
            'email'=>'required|email|unique:student',
            'phone'=>'required'
           ]);
        if($validator->fails()){
         $data = [
             "status"=>422,
             "message"=>$validator->messages()
         ];
             return response()->json($data,422); 
        }else{
             $student = Student::find($id);            
             if($student){
                $student['password']=bcrypt($student['password']);
                $student->update($request->all());   
                $data = [
                    "status"=>200,
                    "message"=>'data updated succefully'
                ];
                return response()->json($data,200);
             }else{
                $data = [
                    "status"=>422,
                    "message"=>'id not found'
                ];
                return response()->json($data,422);
             }      
              
        }
    }
    public function destroy($id){
        $student = Student::find($id);   
        if($student){
            $student->delete();
            $data = [
                "status"=>200,
                "message"=>'data deleted succesfully'
            ];
            return response()->json($data,200);     
        }else{
            $data = [
                "status"=>422,
                "message"=>'id not found'
            ];
            return response()->json($data,422);
         }         
        
    }
}
