<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Admin;
use Illuminate\Support\Facades\DB;
use Auth;
use App\Models\Student;

use function Laravel\Prompts\alert;

class DashboardController extends Controller
{
    public function index() {
        $students = Student::all();
        return view('admin.dashboard')->with('students',$students);
    }
    public function destroy($id) {
        // dd($id);
        $stud = Student::find($id);
        if($stud){
            $stud->delete();
            // return redirect('/admin/dashboard');
        }

        $array = array();
        $array['student'] = $stud;
        $array['success'] = true;
        $array['message'] = 'student deleted successfully!';
        echo json_encode($array);
        
    }
    public function create() {
        return view('admin.adminStudent');
    }
    public function update($id)
    {
        $student = Student::find($id);
        
        if ($student) {
            return view('admin.adminStudent', compact('student'));
        } else {
            return redirect('/dashboard')->with('error_message', 'Invalid student id');
        }
    }
   
}
