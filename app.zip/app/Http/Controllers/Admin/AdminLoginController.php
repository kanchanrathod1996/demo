<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Admin;
use Illuminate\Support\Facades\DB;
use Auth;
use Illuminate\Support\Facades\Mail;
use App\Mail\admin\Login;

class AdminLoginController extends Controller
{
    public function login() {
        
        return view('admin.login');

    }
    public function doLogin(Request $request) {
        //dd($request);
        $input = $request->all();
        $request->validate([
            'username'=>'required',
            'password'=>'required',
        ]);
        $credentials = array(
            'username' => $request->username,
            'password' => $request->password,
            'status' => '1'
        );
        // dd(auth()->guard('admin')->attempt($credentials));
        if (auth()->guard('admin')->attempt($credentials)) {
            
            if(auth()->guard('admin')->user()->status == 1 && auth()->guard('admin')->user()->is_loc == 0){
                Admin::where('id', Auth()->guard('admin')->user()->id)->update(['last_login_time' => DB::raw('CURRENT_TIMESTAMP')]);
                session(['ROLE' => auth()->guard('admin')->user()->role]);
                session(['ADMIN_USER_ID' => auth()->guard('admin')->user()->id]);
                $data=['username' => auth()->guard('admin')->user()->username,
                        'email' =>  auth()->guard('admin')->user()->email
                      ];
                Mail::to('payalvasoya94@gmail.com')->send(new Login($data));
                return redirect(ADMIN_SLUG.'/dashboard');

            }else if(auth()->guard('admin')->user()->status == 0){
                auth()->guard('admin')->logout();
                session()->flush();
                session()->regenerate();
                return redirect(ADMIN_SLUG)->with('error_message', 'Your accont is disabled.');
            }else if(auth()->guard('admin')->user()->is_loc == 1){
                auth()->guard('admin')->logout();
                session()->flush();
                session()->regenerate();
                return redirect(ADMIN_SLUG)->with('error_message', 'Your accont is locked.');
            }
            
        }else{
            return redirect(ADMIN_SLUG)->with('error_message', 'Username or password does not match.');
        }
        
    }

    public function doLogout() {
        
        Auth()->guard('admin')->logout();
        session()->flush();
        session()->regenerate();
        return redirect(ADMIN_SLUG)->with('success_message', 'You are successfully logged out.');
    }
 
}
