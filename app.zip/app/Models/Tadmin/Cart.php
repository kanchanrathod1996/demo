<?php

namespace App\Models\Tadmin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Cart extends Model
{
    use HasFactory;

    protected $table = 'carts';

    protected $fillable = ['id','product_id','quantity','user_id'];

    //Relationship
    public function product() : BelongsTo
    {
        return $this->belongsTo(Product::class,'product_id');
    }
}
