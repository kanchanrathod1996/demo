<?php

namespace App\Models\Tadmin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;


class Product extends Model
{
    use HasFactory;
    protected $table = 'products';
    protected $fillable = ['cat_id','name','description','image','price','status'];

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class,'cat_id');
    }
    public function ingredient(){
        return $this->hasMany(Ingredient::class);
    }
    public function items(): HasMany
    {
        return $this->hasMany(IngredientsItem::class,'product_id');
    }
    public function carts() : HasMany
    {
        return $this->hasMany(Cart::class,'product_id');
    }
}
