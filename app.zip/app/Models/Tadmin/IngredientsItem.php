<?php

namespace App\Models\Tadmin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;


class IngredientsItem extends Model
{
    use HasFactory;
    protected $table = 'ingredients_items';
    protected $fillable = ['product_id','ingredient_id','qunatity','weight','notes'];

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class,'product_id');
    }

    public function ingredient(): BelongsTo
    {
        return $this->belongsTo(Ingredient::class,'ingredient_id');
    }
}
