<?php

namespace App\Models\Tadmin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    use HasFactory;
    protected $table = 'payments';
    protected $fillable = ['order_id','payment_type','payment_id','debug_id','amount','currency','customer_name','customer_email','payment_method','payment_status'];
}
