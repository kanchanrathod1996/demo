<?php

namespace App\Models\Tadmin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Table extends Model
{
    use HasFactory;
    protected $table = 'tables';
    protected $fillable = ['table_number','capacity','availability'];

    public function bookings()
    {
        return $this->hasMany(Booking::class);
    }
}
