<?php

namespace App\Models\Tadmin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;


class IngredientsTypes extends Model
{
    use HasFactory;
    protected $table = 'ingredients_types';
    protected $fillable = ['name','description'];

    public function ingredient(): HasMany
    {
        return $this->hasMany(Ingredient::class, 'ingredient_type_id');
    }
}
