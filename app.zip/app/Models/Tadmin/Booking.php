<?php

namespace App\Models\Tadmin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class Booking extends Model
{
    use HasFactory;
    protected $table = 'reservations';
    protected $fillable = ['user_id','table_id','username','mobile_no','email','number_of_guests','availability','book_date']; 
    
    public function user()
    {
        return $this->belongsTo(User::class,'user_id');
    }
    public function table()
    {
        return $this->belongsTo(Table::class,'table_id');
    }
}
