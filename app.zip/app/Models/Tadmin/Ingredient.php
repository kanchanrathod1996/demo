<?php

namespace App\Models\Tadmin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Facades\Hash;
use Illuminate\Database\Eloquent\Relations\HasMany;


class Ingredient extends Model
{
    use HasFactory;
    protected $table = 'ingredients';
    protected $fillable = ['name','ingredient_type_id','image','description'];

    public function ingredientType(): BelongsTo
    {
        return $this->belongsTo(IngredientsTypes::class, 'ingredient_type_id');
    }
    
    public function product(){
        return $this->belongsTo(Product::class);
    }
}
