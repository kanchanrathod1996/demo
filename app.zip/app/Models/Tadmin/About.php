<?php

namespace App\Models\Tadmin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;

class About extends Model
{
    use HasFactory;
    protected $table = 'about_us';
    protected $fillable = ['title','description','image'];
}
