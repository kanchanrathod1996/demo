<?php

namespace App\Mail\admin;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\EmailTemplate;

class Login extends Mailable
{
    use Queueable, SerializesModels;
    
    /**
     * The email template instance.
     *
     * @var EmailTemplate
     */
    public $data;


    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($data){
        
        $this->data = $data;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build(){
        
        $subject = "WELCOME - DEMO.COM";
        
        return $this->view('admin.emails.welcomeLogin')->subject($subject)->from(config('settings.booking_email'),config('settings.mail_from_name'));
    }
}