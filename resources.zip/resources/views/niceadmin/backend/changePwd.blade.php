@extends('niceadmin.backend.layouts.default')

@section('content') 

<main id="main" class="main">

    <div class="pagetitle">
        <h1>Change Password</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{!! url(ADMIN_SLUG.'/dashboard') !!}">Home</a></li>
                <li class="breadcrumb-item">Change Password</li>
            </ol>
        </nav>
    </div>

    <section class="section">
      <div class="row">

        <div class="col-lg-12">
            @include('niceadmin.backend.includes.notifications')
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title"></h6>
                    {!! Form::open(['url' => 'admin/password/change', 'id' => 'change-password-form', 'class'=>"row g-3",'novalidate' => 'novalidate']) !!}
                        <div class="col-12">
                            {!! Form::label('Old Password',null,['class'=>'form-label']) !!}
                            {!! Form::password('old_password', ['class'=>'form-control']) !!}
                        </div>
                        <div class="col-12">
                            {!! Form::label('New Password',null,['class'=>'form-label']) !!}
                            {!! Form::password('password', ['class'=>'form-control','id'=>'password']) !!}
                        </div>
                        <div class="col-12">
                            {!! Form::label('Confirm Password',null,['class'=>'form-label']) !!}
                            {!! Form::password('password_confirmation', ['class'=>'form-control']) !!}
                        </div>
                        <div class="text-right">
                            {!! Form::submit('Submit',array('class'=>'btn btn-primary')) !!}
                            <a href="{!! url(ADMIN_SLUG.'/dashboard') !!}" class="btn btn-secondary">Cancel</a>
                        </div>
                    {!! Form::close()!!}
                </div>
            </div>

        </div>
      </div>
    </section>

  </main>

@endsection