@extends('niceadmin.backend.layouts.default')
@section('content') 
<main id="main" class="main">
    <div class="pagetitle">
      <h1>AboutUs</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="{{url(ADMIN_SLUG)}}">Home</a></li>
          <li class="breadcrumb-item">About Us</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title text-end"><a href="{{ url('admin/about/create') }}">Add</a></h5>

              <!-- Default Table -->
              <table class="table data-table" id="about_list">
                <thead>
                  <tr>
                    <th scope="col">Title</th>
                    <th scope="col" >Description</th>
                    <th scope="col" >Image</th>
                    <th scope="col" >Action</th>
                  </tr>
                </thead>
                <tbody>
                  @foreach ($abouts as $about)
                    <tr>
                      <td>{{$about->title}}</td>
                      <td>{{$about->description}}</td>
                      <td><img src="{{asset(ABOUT_IMAGE_ROOT).$about->image}}" width="50" height="50"></td>
                      <td><a href="about/{{$about->id}}/edit" class="edit btn btn-primary btn-sm">edit</a> <a href="javascript:;" class="btn btn-danger btn-sm delete-btn" id="{{$about->id}}">delete</a></td>
                    </tr>
                  @endforeach
                </tbody>
              </table>
              <!-- End Default Table Example -->
            </div>
          </div>
      </div>
    </section>

  </main><!-- End #main -->
@endsection

@section('script')
<script>
   $("#about_list").on('click', '.delete-btn', function() {
            var id = $(this).attr('id');
            console.log(id);
            var r = confirm("Are you sure to delete about data?");
            if (!r) {
                return false
            }
            $.ajax({
                type: "POST",
                url: "about/" + id,
                data: {
                    _method: 'DELETE',
                    _token: "{!! csrf_token() !!}"
                },
                dataType: 'json',
                beforeSend: function() {
                    $(this).attr('disabled', true);
                    $('.alert .msg-content').html('');
                    $('.alert').hide();
                },
                success: function(resp) {
                    if (resp.success) {
                        window.location.href=window.location.href
                        $('.alert-success .msg-content').html(resp.message);
                        $('.alert-success').show();
                    } else {
                        $('.alert-danger .msg-content').html(resp.message);
                        $('.alert-danger').show();
                    }
                    $(this).attr('disabled', false);
                },
                error: function(e) {
                    alert('Error: ' + e);
                }
            });
        });
</script>
@endsection