@extends('niceadmin.backend.layouts.default')

@section('content') 

<main id="main" class="main">

    <div class="pagetitle">
        <h1>{!! (isset($about)) ? 'Edit' : 'Add' !!} about</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{!! url(ADMIN_SLUG.'/dashboard') !!}">Home</a></li>
                <li class="breadcrumb-item"><a href="{!! url(ADMIN_SLUG.'/category') !!}">AboutUs List</a></li>
                <li class="breadcrumb-item">AboutUs</li>
            </ol>
        </nav>
    </div>

    <section class="section">
      <div class="row">
        <div class="col-lg-12">
            @include('niceadmin.backend.includes.notifications')
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title"></h6>
                    @if(isset($about))
                        {!! Form::model($about, ['route' => array('about.update', $about->id),'method' => 'PATCH', 'id' => 'about-form',  'class'=>"row g-3",'files' => true, 'enctype' => 'multipart/form-data']) !!}
                    @else
                        {!! Form::open(['route' => 'about.store', 'id' => 'about-form', 'class'=>"row g-3",'files' => true]) !!}
                    @endif                    
                        <div class="col-12">
                            {!! Form::label('Title',null,['class'=>'form-label']) !!}
                            {!! Form::text('title', old('title'),['class'=>'form-control']) !!}
                        </div>
                        <div class="col-12">
                            {!! Form::label('Description',null,['class'=>'form-label']) !!}
                            {!! Form::textarea('description',old('description'),['id'=>'description','class'=>'form-control','rows'=>"2"]) !!}
                        </div>
                            
                        <div class="col-12">   
                            @if(isset($about))
                                <img src="{{ABOUT_IMAGE_ROOT.$about->image}}" height="50px" width="50px">
                            @endif                         
                            {!! Form::file('image',null,['class'=>'form-control']) !!}                           
                        </div>

                        <div class="text-right">
                            {!! Form::submit('Submit',array('class'=>'btn btn-primary')) !!}
                            <a href="{!! url(ADMIN_SLUG.'/about') !!}" class="btn btn-secondary">Cancel</a>
                        </div>
                    {!! Form::close()!!}
                </div>
            </div>

        </div>
      </div>
    </section>

  </main>

@endsection