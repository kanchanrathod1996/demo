@extends('niceadmin.backend.layouts.default')

@section('content') 

<main id="main" class="main">

    <div class="pagetitle">
        <h1>{!! (isset($ingredient)) ? 'Edit' : 'Add' !!} Ingredient</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{!! url(ADMIN_SLUG.'/dashboard') !!}">Home</a></li>
                <li class="breadcrumb-item"><a href="{!! url(ADMIN_SLUG.'/ingredient') !!}">Ingredient List</a></li>
                <li class="breadcrumb-item">Ingredient</li>
            </ol>
        </nav>
    </div>

    <section class="section">
      <div class="row">

        <div class="col-lg-12">
            @include('niceadmin.backend.includes.notifications')
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title"></h6>
                    {{-- @dd($ingredient->image) --}}
                    @if(isset($ingredient))
                        {!! Form::model($ingredient, ['route' => array('ingredient.update', $ingredient->id),'method' => 'PATCH', 'id' => 'ingredient-form',  'class'=>"row g-3",'files' => true,'enctype' => 'multipart/form-data']) !!}
                    @else
                        {!! Form::open(['route' => 'ingredient.store', 'id' => 'ingredient-form', 'class'=>"row g-3",'files' => true]) !!}
                    @endif  
                    <div class="col-12">
                      <div class="card">
                          <div class="card-body">
                              <h5 class="card-title">Ingredients Item</h5>
                  
                              <!-- Accordion without outline borders -->
                              <div class="accordion accordion-flush" id="accordionFlushExample">
                                  <div class="accordion-item">
                                      <h2 class="accordion-header" id="flush-headingOne">
                                          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                                              Ingredients Item
                                          </button>
                                      </h2>
                                      <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                                          <div class="accordion-body">
                                              {!! Form::label('Select ingredients', null, ['class'=>'form-label']) !!}
                                              {!! Form::select('ingredient_type_id', $IngredientsTypes, null, ['class'=>'form-control', 'placeholder'=>'Please select ...']) !!}
                                          </div>
                                      </div>
                                  </div>
                              </div><!-- End Accordion without outline borders -->
                  
                          </div>
                      </div>
                    </div>
                  
                        <div class="col-12">
                            {!! Form::label('Ingredient Name',null,['class'=>'form-label']) !!}
                            {!! Form::text('name', old('name'),['class'=>'form-control']) !!}
                        </div>

                        <div class="col-12">   
                            {{-- @dd($ingredient) --}}
                            @if(isset($ingredient))
                                <img src="{{INGREDIENT_IMAGE_ROOT.$ingredient->image}}" height="50px" width="50px">
                            @endif                         
                            {!! Form::file('image',null,['class'=>'form-control']) !!}                           
                        </div>

                        <div class="col-12">
                            {!! Form::label('Description',null,['class'=>'form-label']) !!}
                            {!! Form::textarea('description',old('description'),['id'=>'description','class'=>'form-control','rows'=>"2"]) !!}
                        </div>
                 
                        <div class="text-right">
                            {!! Form::submit('Submit',array('class'=>'btn btn-primary')) !!}
                            <a href="{!! url(ADMIN_SLUG.'/ingredient') !!}" class="btn btn-secondary">Cancel</a>
                        </div>
                    {!! Form::close()!!}
                </div>
            </div>

        </div>
      </div>
    </section>

  </main>

@endsection