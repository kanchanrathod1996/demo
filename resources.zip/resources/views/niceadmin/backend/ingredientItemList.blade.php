@extends('niceadmin.backend.layouts.default')
@section('content') 
<main id="main" class="main">
    <div class="pagetitle">
      <h1>IngredientItem List</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="{{url(ADMIN_SLUG)}}">Home</a></li>
          <li class="breadcrumb-item">IngredientItem List</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              {{-- <h5 class="card-title text-end"><a href="{{ url('admin/ingredientItem/create') }}">Add IngredientItem</a></h5> --}}

              <!-- Default Table -->
              <table class="table data-table" id="ingredientItem_list">
                <thead>
                  <tr>
                    <th scope="col">ProductName</th>
                    <th scope="col" >IngredientsName</th>
                    <th scope="col" >Qunatity</th>
                    <th scope="col" >weight</th>
                    <th scope="col" >notes</th>
                    <th scope="col" >Action</th>
                  </tr>
                </thead>
                <tbody>
                  @foreach ($ingredientsItems as $ingredientsItem)
                    <tr>
                      <td>{{$ingredientsItem->product->name}}</td>
                      <td>{{$ingredientsItem->ingredient->name}}</td>
                      <td>{{$ingredientsItem->qunatity}}</td>
                      <td>{{$ingredientsItem->weight}}</td>
                      <td>{{$ingredientsItem->notes}}</td>
                      <td>
                        {{-- <a href="ingredientsItem/{{$ingredientsItem->id}}/edit" class="edit btn btn-primary btn-sm">edit</a> --}}
                         <a href="javascript:;" class="btn btn-danger btn-sm delete-btn" id="{{$ingredientsItem->id}}">delete</a></td>
                    </tr>
                  @endforeach
                </tbody>
              </table>
              <!-- End Default Table Example -->
            </div>
          </div>
      </div>
    </section>

  </main><!-- End #main -->
@endsection

@section('script')
<script>

    $("#ingredientItem_list").on('click', '.delete-btn', function() {
        var id = $(this).attr('id');
        var r = confirm("Are you sure to delete this product?");
        if (!r) {
            return false
        }
        $.ajax({
            type: "POST",
            url: "ingredientItem/" + id,
            data: {
                _method: 'DELETE',
                _token:"{!! csrf_token() !!}"
            },
            dataType: 'json',
            beforeSend: function() {
                $(this).attr('disabled', true);
                $('.alert .msg-content').html('');
                $('.alert').hide();
            },
            success: function(resp) {
                if (resp.success) {
                  window.location.href=window.location.href
                    $('.alert-success .msg-content').html(resp.message);
                    $('.alert-success').show();
                } else {
                    $('.alert-danger .msg-content').html(resp.message);
                    $('.alert-danger').show();
                }
                $(this).attr('disabled', false);
                table.draw();
            },
            error: function(e) {
                alert('Error: ' + e);
            }
        });
    });
</script>
@endsection