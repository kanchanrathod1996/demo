@extends('niceadmin.backend.layouts.default')
@section('content') 
<main id="main" class="main">
    <div class="pagetitle">
      <h1>Tables List</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="{{url(ADMIN_SLUG)}}">Home</a></li>
          <li class="breadcrumb-item">Table</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title text-end"><a href="{{ url('admin/table/create') }}">Add</a></h5>

              <!-- Default Table -->
              <table class="table data-table" id="table_list">
                <thead>
                  <tr>
                    <th scope="col">Table Number</th>
                    <th scope="col">Capacity</th>
                    <th scope="col">Availability</th>
                    <th scope="col" >Action</th>
                  </tr>
                </thead>
                <tbody>
                  @foreach ($tables as $table)
                  <tr>
                      <td>T{{$table->table_number}}</td>
                      <td>{{$table->capacity}}</td>
                      @if ($table->availability===1)
                      <td><a href="javascript:;" class="badge rounded-pill text-bg-success availability-btn" id="{{$table->id}}">Available</a>                            
                      @else
                      <td><a href="javascript:;" class="badge rounded-pill text-bg-danger availability-btn" id="{{$table->id}}">Reserved</a>                            
                      @endif
                      <td><a href="table/{{$table->id}}/edit" class="edit btn btn-primary btn-sm">edit</a> <a href="javascript:;" class="btn btn-danger btn-sm delete-btn" id="{{$table->id}}">delete</a></td>
                  </tr>
                    @endforeach  

                </tbody>
              </table>
              <!-- End Default Table Example -->
            </div>
          </div>
      </div>
    </section>

  </main><!-- End #main -->
@endsection

@section('script')
<script>
   $("#table_list").on('click', '.delete-btn', function() {
            var id = $(this).attr('id');
            console.log(id);
            var r = confirm("Are you sure to delete table data?");
            if (!r) {
                return false
            }
            $.ajax({
                type: "POST",
                url: "table/" + id,
                data: {
                    _method: 'DELETE',
                    _token: "{!! csrf_token() !!}"
                },
                dataType: 'json',
                beforeSend: function() {
                    $(this).attr('disabled', true);
                    $('.alert .msg-content').html('');
                    $('.alert').hide();
                },
                success: function(resp) {
                    if (resp.success) {
                        window.location.href=window.location.href
                        $('.alert-success .msg-content').html(resp.message);
                        $('.alert-success').show();
                    } else {
                        $('.alert-danger .msg-content').html(resp.message);
                        $('.alert-danger').show();
                    }
                    $(this).attr('disabled', false);
                },
                error: function(e) {
                    alert('Error: ' + e);
                }
            });
        });
</script>
<script>
 $("#table_list").on('click', '.availability-btn', function() {
        var id = $(this).attr('id');
        // alert(id);
        var r = confirm("Are you sure to change avability?");
        if (!r) {
            return false
        }
        $.ajax({
            type: "POST",
            url: "{!! URL::to('admin/table/changeAvability') !!}",
            data: {
                id: id,
                _token:"{!! csrf_token() !!}"
            },
            dataType: 'json',
            beforeSend: function() {
                $(this).attr('disabled', true);
                $('.alert .msg-content').html('');
                $('.alert').hide();
            },
            success: function(resp) {
                if (resp.success) {
                  window.location.href=window.location.href
                    $('.alert-success .msg-content').html(resp.message);
                    $('.alert-success').show();
                } else {
                    $('.alert-danger .msg-content').html(resp.message);
                    $('.alert-danger').show();
                }
            },
            error: function(e) {
                alert('Error: ' + e);
            }
        });
    });
</script>
@endsection