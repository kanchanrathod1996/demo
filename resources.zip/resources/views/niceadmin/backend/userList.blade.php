@extends('niceadmin.backend.layouts.default')
@section('content') 
<main id="main" class="main">
    <div class="pagetitle">
      <h1>UserList</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="{{url(ADMIN_SLUG)}}">Home</a></li>
          <li class="breadcrumb-item">UserList</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              {{-- <h5 class="card-title text-end"><a href="{{ url('admin/about/create') }}">Add</a></h5> --}}

              <!-- Default Table -->
              <table class="table data-table" id="user_list">
                <thead>
                  <tr>
                    <th scope="col">UserName</th>
                    <th scope="col" >Email</th>
                    <th scope="col" >ContactNumber</th>
                    <th scope="col" >Status</th>
                    <th scope="col" >Action</th>
                  </tr>
                </thead>
                <tbody>
                  @foreach ($users as $user)
                    <tr>
                      <td>{{$user->username}}</td>
                      <td>{{$user->email}}</td>
                      <td>{{$user->contact_number}}</td>
                      @if ($user->status===1)
                      
                      <td><a href="javascript:;" class="btn btn-success status-btn btn-sm" id="{{$user->id}}"><i class="bi bi-lightbulb"></i></a>                            
                      @else
                      <td><a href="javascript:;" class="btn btn-danger status-btn btn-sm" id="{{$user->id}}"><i class="bi bi-lightbulb"></i></a>                            
                      @endif
                      <td>
                        {{-- <a href="user/{{$user->id}}/edit" class="edit btn btn-primary btn-sm">edit</a> --}}
                         <a href="javascript:;" class="btn btn-danger btn-sm delete-btn" id="{{$user->id}}">delete</a></td>
                    </tr>
                  @endforeach
                </tbody>
              </table>
              <!-- End Default Table Example -->
            </div>
          </div>
      </div>
    </section>

  </main><!-- End #main -->
@endsection

@section('script')
<script>
   $("#user_list").on('click', '.delete-btn', function() {
            var id = $(this).attr('id');
            console.log(id);
            var r = confirm("Are you sure to delete user data?");
            if (!r) {
                return false
            }
            $.ajax({
                type: "POST",
                url: "user/" + id,
                data: {
                    _method: 'DELETE',
                    _token: "{!! csrf_token() !!}"
                },
                dataType: 'json',
                beforeSend: function() {
                    $(this).attr('disabled', true);
                    $('.alert .msg-content').html('');
                    $('.alert').hide();
                },
                success: function(resp) {
                    if (resp.success) {
                        window.location.href=window.location.href
                        $('.alert-success .msg-content').html(resp.message);
                        $('.alert-success').show();
                    } else {
                        $('.alert-danger .msg-content').html(resp.message);
                        $('.alert-danger').show();
                    }
                    $(this).attr('disabled', false);
                },
                error: function(e) {
                    alert('Error: ' + e);
                }
            });
  });

</script>
<script>
 $("#user_list").on('click', '.status-btn', function() {
        var id = $(this).attr('id');
        //alert(id);
        var r = confirm("Are you sure to change status?");
        if (!r) {
            return false
        }
        $.ajax({
            type: "POST",
            url: "{!! URL::to('admin/user/changeStatus') !!}",
            data: {
                id: id,
                _token:"{!! csrf_token() !!}"
            },
            dataType: 'json',
            beforeSend: function() {
                $(this).attr('disabled', true);
                $('.alert .msg-content').html('');
                $('.alert').hide();
            },
            success: function(resp) {
                if (resp.success) {
                  window.location.href=window.location.href
                    $('.alert-success .msg-content').html(resp.message);
                    $('.alert-success').show();
                } else {
                    $('.alert-danger .msg-content').html(resp.message);
                    $('.alert-danger').show();
                }
            },
            error: function(e) {
                alert('Error: ' + e);
            }
        });
    });
</script>
@endsection