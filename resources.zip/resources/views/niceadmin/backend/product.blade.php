@extends('niceadmin.backend.layouts.default')
@section('content') 
<main id="main" class="main">
    <div class="pagetitle">
        <h1>{!! (isset($product)) ? 'Edit' : 'Add' !!} Product</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{!! url(ADMIN_SLUG.'/dashboard') !!}">Home</a></li>
                <li class="breadcrumb-item"><a href="{!! url(ADMIN_SLUG.'/category') !!}">Product List</a></li>
                <li class="breadcrumb-item">Product</li>
            </ol>
        </nav>
    </div>

    <section class="section">
      <div class="row">

        <div class="col-lg-12">
            @include('niceadmin.backend.includes.notifications')
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title"></h6>
                    @if(isset($product))
                    {{-- @dd('edit') --}}
                        {!! Form::model($product, ['route' => array('product.update', $product->id),'method' => 'PATCH', 'id' => 'product-form',  'class'=>"row g-3",'files' => true,'enctype' => 'multipart/form-data']) !!}
                    @else
                        {!! Form::open(['route' => 'product.store', 'id' => 'product-form', 'class'=>"row g-3",'files' => true]) !!}
                    @endif  
                    <div class="col-12 form-group">
                        {!! Form::label('Select category',null,['class'=>'form-label']) !!}
                        {!! Form::select('cat_id', $catList, isset($product->cat_id) ? $product->cat_id : null,['class'=>'form-control','placeholder'=>'Please select ...']) !!}
                    </div>                  
                        <div class="col-12 form-group">
                            {!! Form::label('Product Name',null,['class'=>'form-label']) !!}
                            {!! Form::text('name', old('name'),['class'=>'form-control']) !!}
                        </div>
                        <div class="col-12 form-group">
                            {!! Form::label('Description',null,['class'=>'form-label']) !!}
                            {!! Form::textarea('description',old('description'),['id'=>'description','class'=>'form-control','rows'=>"2"]) !!}
                        </div>
                        <div class="col-12 form-group">
                            {!! Form::label('Price',null,['class'=>'form-label']) !!}
                            {!! Form::text('price', old('price'),['class'=>'form-control']) !!}
                        </div>
                        <div class="col-12 form-group">   
                            @if(isset($product))
                                <img src="{{PRODUCT_IMAGE_ROOT.$product->image}}" height="50px" width="50px">
                            @endif                         
                            {!! Form::file('image',null,['class'=>'form-control']) !!}                           
                        </div>

                        <div class="accordion accordion-flush" id="accordionFlushExample1">
                            <!-- Accordion Item -->
                            <div class="accordion-item">
                                <!-- Accordion Header -->
                                <h2 class="accordion-header" id="flush-headingOne">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseTwo">
                                        Ingredients Items
                                    </button>
                                </h2>
                                <!-- Accordion Body -->
                                <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample1">
                                    <div class="accordion-body">
                                        <!-- Form for Adding Ingredients -->
                                        @if(isset($product) && (isset($ingredientsItem) && !$ingredientsItem->isEmpty()))
                                        {{-- @dd(isset($ingredientsItem)) --}}

                                        @foreach($ingredientsItem as $ingredient)
                                        <div class="row">
                                            <!-- Ingredient Selection Dropdown -->
                                            <div class="col-3 form-group">
                                                {!! Form::label('Select ingredients',null, ['class'=>'form-label']) !!}
                                                {!! Form::select('ingredient_id[]',$ingredientList, $ingredient->ingredient_id, ['class'=>'form-control', 'placeholder'=>'Please select ...']) !!}
                                            </div>
                                            <!-- Quantity Input Field -->
                                            <div class="col-3 form-group">
                                                {!! Form::label('Quantity', null, ['class'=>'form-label']) !!}
                                                {!! Form::text('qunatity[]', old('qunatity', $ingredient->qunatity), ['class'=>'form-control numberInput']) !!}
                                            </div>
                                            <!-- Weight Input Field -->
                                            <div class="col-3 form-group">
                                                {!! Form::label('Weight', null, ['class'=>'form-label']) !!}
                                                {!! Form::text('weight[]', old('weight', $ingredient->weight), ['class'=>'form-control numberInput']) !!}
                                            </div>
                                            <!-- Notes Textarea Field -->
                                            <div class="col-3 form-group">
                                                {!! Form::label('Notes', null, ['class'=>'form-label']) !!}
                                                {!! Form::textarea('notes[]', old('notes', $ingredient->notes), ['id'=>'notes', 'class'=>'form-control', 'rows'=>"1"]) !!}
                                            </div>

                                            {{-- <div class="col-1 form-group">
                                                <button type="button" class="btn btn-danger remove-row mt-2">Remove</button>
                                            </div> --}}

                                        </div>                                        
                                        @endforeach
                                        @elseif(!isset($product) || (isset($ingredientsItem) && $ingredientsItem->isEmpty()))
                                        <div class="row">
                                            <!-- Ingredient Selection Dropdown -->
                                            <div class="col-3 form-group">
                                                {!! Form::label('Select ingredients', null, ['class'=>'form-label']) !!}
                                                {!! Form::select('ingredient_id[]',$ingredientList,null, ['class'=>'form-control', 'placeholder'=>'Please select ...']) !!}
                                            </div>
                                            <!-- Quantity Input Field -->
                                            <div class="col-3 form-group">
                                                {!! Form::label('Quantity', null, ['class'=>'form-label']) !!}
                                                {!! Form::text('qunatity[]', null, ['class'=>'form-control numberInput']) !!}
                                            </div>
                                            <!-- Weight Input Field -->
                                            <div class="col-3 form-group">
                                                {!! Form::label('Weight', null, ['class'=>'form-label']) !!}
                                                {!! Form::text('weight[]', null, ['class'=>'form-control numberInput']) !!}
                                            </div>
                                            <!-- Notes Textarea Field -->
                                            <div class="col-3 form-group">
                                                {!! Form::label('Notes', null, ['class'=>'form-label']) !!}
                                                {!! Form::textarea('notes[]',null, ['id'=>'notes', 'class'=>'form-control', 'rows'=>"1"]) !!}
                                            </div>
                                            {{-- <div class="col-1 form-group">
                                                <button type="button" class="btn btn-danger remove-row mt-2">Remove</button>
                                            </div> --}}
                                        </div>                                       
                                        @endif
                                    </div>
                                    <!-- Button for Adding Ingredient Rows Dynamically -->
                                    <button type="button" class="btn btn-primary mt-3" id="addIngredientRow">Add Ingredient</button>

                                </div>
                            </div>
                        </div>
                        

                        <div class="text-right">
                            {!! Form::submit('Submit',array('class'=>'btn btn-primary')) !!}
                            <a href="{!! url(ADMIN_SLUG.'/product') !!}" class="btn btn-secondary">Cancel</a>
                        </div>
                    {!! Form::close()!!}
                </div>
            </div>

        </div>
      </div>
    </section>

  </main>
@endsection
@section('script')
    <script type="text/javascript">
     $('input').attr('autocomplete','off');
            $(document).ready(function () {
                var ingredientRow = `
                <div class="row mb-3">
                    <div class="col-3 form-group">
                        <label class="form-label" >Select ingredients</label>
                        <select class="form-control" name="ingredient_id[]" >
                            <option value="" selected disabled>Please select ...</option>
                            @foreach ($ingredientList as $k=>$v)
                            <option value="{{$k}}"> {{ $v }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-3 form-group">
                        <label class="form-label" >Quantity</label>
                        <input type="text" class="form-control numberInput" name="qunatity[]" value="{{ old('qunatity[]') }}">
                    </div>
                    <div class="col-3 form-group">
                        <label class="form-label" >Weight</label>
                        <input type="text" class="form-control numberInput" name="weight[]" value="{{ old('weight[]') }}">
                    </div>
                    <div class="col-3 form-group">
                        <label class="form-label" >Notes</label>
                        <textarea class="form-control"  name="notes[]" rows="1">{{ old('notes[]') }}</textarea>
                    </div>
                    
                    <div class="col-1 form-group">
                        <button type="button" class="btn btn-danger remove-row mt-2">Remove</button>
                    </div>
                </div>  
                `;

                $('#addIngredientRow').on('click', function () {
                    $('.accordion-body').append(ingredientRow);
                    $(".numberInput").forceNumeric();
                });

                $(document).on('click', '.remove-row', function () {
                    $(this).closest('.row').remove();
                });                
            });
    </script>


@endsection