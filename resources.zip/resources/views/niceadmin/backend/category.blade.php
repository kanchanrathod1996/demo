@extends('niceadmin.backend.layouts.default')

@section('content') 

<main id="main" class="main">

    <div class="pagetitle">
        <h1>{!! (isset($cat)) ? 'Edit' : 'Add' !!} Category</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{!! url(ADMIN_SLUG.'/dashboard') !!}">Home</a></li>
                <li class="breadcrumb-item"><a href="{!! url(ADMIN_SLUG.'/category') !!}">Category List</a></li>
                <li class="breadcrumb-item">Category</li>
            </ol>
        </nav>
    </div>

    <section class="section">
      <div class="row">

        <div class="col-lg-12">
            @include('niceadmin.backend.includes.notifications')
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title"></h6>
                    @if(isset($cat))
                        {!! Form::model($cat, ['route' => array('category.update', $cat->id),'method' => 'PATCH', 'id' => 'category-form',  'class'=>"row g-3",'files' => true]) !!}
                    @else
                        {!! Form::open(['route' => 'category.store', 'id' => 'category-form', 'class'=>"row g-3",'files' => true]) !!}
                    @endif                    
                        <div class="col-12">
                            {!! Form::label('Category Name',null,['class'=>'form-label']) !!}
                            {!! Form::text('cat_name', old('cat_name'),['class'=>'form-control']) !!}
                        </div>
                        <div class="text-right">
                            {!! Form::submit('Submit',array('class'=>'btn btn-primary')) !!}
                            <a href="{!! url(ADMIN_SLUG.'/category') !!}" class="btn btn-secondary">Cancel</a>
                        </div>
                    {!! Form::close()!!}
                </div>
            </div>

        </div>
      </div>
    </section>

  </main>

@endsection