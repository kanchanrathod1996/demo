  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

      <li class="nav-item">
        <a class="nav-link " href="{{url(ADMIN_SLUG.'/dashboard')}}">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
      </li><!-- End Dashboard Nav -->

      <li class="nav-item">
        <a class="nav-link {{ (Request::is(ADMIN_SLUG.'/product*')? '' : 'collapsed') }}" data-bs-target="#product-nav" data-bs-toggle="collapse" href="#" aria-expanded="{{ (Request::is(ADMIN_SLUG.'/product/*')? 'true':'false')}}">
          <i class="bi bi-handbag-fill"></i><span>Products</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="product-nav" class="nav-content collapse {{ (Request::is(ADMIN_SLUG.'/product*')? 'show' : '') }}" data-bs-parent="#sidebar-nav">
          <li>
            <a href="{{url(ADMIN_SLUG.'/product')}}" class="{!! (Request::is(ADMIN_SLUG.'/product*') ? 'active' : '') !!}">
              <i class="bi bi-pencil-square"></i> <span>Product List</span>
            </a>
          </li>
        </ul>
      </li>

      <li class="nav-item">
        <a class="nav-link {{ (Request::is(ADMIN_SLUG.'/settings/*') || Request::is(ADMIN_SLUG.'/profile') || Request::is(ADMIN_SLUG.'/password/change') ? '' : 'collapsed') }}" data-bs-target="#setting-nav" data-bs-toggle="collapse" href="#" aria-expanded="{{ (Request::is(ADMIN_SLUG.'/settings/*') || Request::is(ADMIN_SLUG.'/profile') || Request::is(ADMIN_SLUG.'/password/change') ? 'true' : 'false') }}">
          <i class="bi bi-gear"></i><span>Settings</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="setting-nav" class="nav-content collapse {{ (Request::is(ADMIN_SLUG.'/settings/*') || Request::is(ADMIN_SLUG.'/profile') || Request::is(ADMIN_SLUG.'/password/change') ? 'show' : '') }}" data-bs-parent="#sidebar-nav">
          <li>
            <a href="{{url(ADMIN_SLUG.'/settings')}}"  class="{!! (Request::is(ADMIN_SLUG.'/settings/*') ? 'active' : '') !!}">
              <i class="bi bi-wrench"></i><span>Change setting</span>
            </a>
          </li>
          <li>
            <a href="{{url(ADMIN_SLUG.'/profile')}}" class="{!! (Request::is(ADMIN_SLUG.'/profile') ? 'active' : '') !!}">
              <i class="bi bi-person-circle"></i> <span>Admin Profile</span>
            </a>
          </li>
          <li>
            <a href="{{url(ADMIN_SLUG.'/password/change')}}" class="{!! (Request::is(ADMIN_SLUG.'/password/change') ? 'active' : '') !!}">
              <i class="bi bi-person-fill-lock"></i> <span>Change password</span>
            </a>
          </li>
        </ul>
      </li>




{{-- demo start--}}
<li class="nav-item">
  <a class="nav-link {{ (Request::is(ADMIN_SLUG.'/ingredientType/*') || Request::is(ADMIN_SLUG.'/ingredient') || Request::is(ADMIN_SLUG.'/ingredientItem') ? '' : 'collapsed') }}" data-bs-target="#ingredients-nav" data-bs-toggle="collapse" href="#" aria-expanded="{{ (Request::is(ADMIN_SLUG.'/ingredientType/*') || Request::is(ADMIN_SLUG.'/ingredient') || Request::is(ADMIN_SLUG.'/ingredientItem') ? 'true' : 'false') }}">
      <i class="bi bi-list"></i><span>Ingredients</span><i class="bi bi-chevron-down ms-auto"></i>
  </a>
  <ul id="ingredients-nav" class="nav-content collapse {{ (Request::is(ADMIN_SLUG.'/ingredientType/*') || Request::is(ADMIN_SLUG.'/ingredient') || Request::is(ADMIN_SLUG.'/ingredientItem') ? 'show' : '') }}" data-bs-parent="#sidebar-nav">
      <li>
          <a href="{{url(ADMIN_SLUG.'/ingredientType')}}"  class="{!! (Request::is(ADMIN_SLUG.'/ingredientType/*') ? 'active' : '') !!}">
              <i class="bi bi-pencil-square"></i><span>Manage IngredientsType</span>
          </a>
      </li>
      <li>
          <a href="{{url(ADMIN_SLUG.'/ingredient')}}" class="{!! (Request::is(ADMIN_SLUG.'/ingredient') ? 'active' : '') !!}">
              <i class="bi bi-pencil-square"></i> <span>Manage Ingredients</span>
          </a>
      </li>
      <li>
          <a href="{{url(ADMIN_SLUG.'/ingredientItem')}}" class="{!! (Request::is(ADMIN_SLUG.'/ingredientItem') ? 'active' : '') !!}">
              <i class="bi bi-pencil-square"></i> <span>Manage Ingredients Item</span>
          </a>
      </li>
  </ul>
</li>

{{--  demo end--}}


      <li class="nav-item">
        <a class="nav-link {!! (Request::is(ADMIN_SLUG.'/category*') ? '' : 'collapsed') !!}" data-bs-target="#category-nav" data-bs-toggle="collapse" href="#" aria-expanded="{{ (Request::is(ADMIN_SLUG.'/category/*')? 'true' : 'false') }}">
          <i class="bi bi-stack"></i><span>Category</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="category-nav" class="nav-content collapse {!! (Request::is(ADMIN_SLUG.'/category*') ? 'show' : '') !!}" data-bs-parent="#sidebar-nav">
          <li>
            <a href="{{url(ADMIN_SLUG.'/category')}}" class="{!! (Request::is(ADMIN_SLUG.'/category*') ? 'active' : '') !!}">
              <i class="bi bi-pencil-square"></i> <span>Category List</span>
            </a>
          </li>
        </ul>
      </li>

      <li class="nav-item">
        <a class="nav-link {!! (Request::is(ADMIN_SLUG.'/table*') ? '' : 'collapsed') !!}" data-bs-target="#table-nav" data-bs-toggle="collapse" href="#" aria-expanded="{{ (Request::is(ADMIN_SLUG.'/table/*')? 'true' : 'false') }}">
          <i class="bi bi-stack"></i><span>Table</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="table-nav" class="nav-content collapse {!! (Request::is(ADMIN_SLUG.'/table*') ? 'show' : '') !!}" data-bs-parent="#sidebar-nav">
          <li>
            <a href="{{url(ADMIN_SLUG.'/table')}}" class="{!! (Request::is(ADMIN_SLUG.'/table*') ? 'active' : '') !!}">
              <i class="bi bi-pencil-square"></i> <span>Table List</span>
            </a>
          </li>
        </ul>
      </li>
      <!-- End Icons Nav -->

      <li class="nav-heading">Pages</li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="{{url(ADMIN_SLUG.'/about')}}">
          <i class="bi bi-info-circle"></i>
          <span>About Us</span>
        </a>
      </li><!-- about us Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="{{url(ADMIN_SLUG.'/slider')}}">
          <i class="bi bi-info-circle"></i>
          <span>Slider</span>
        </a>
      </li><!-- slider Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="{{url(ADMIN_SLUG.'/user')}}">
          <i class="bi bi-info-circle"></i>
          <span>User List</span>
        </a>
      </li><!-- user nav -->
    </ul>

  </aside><!-- End Sidebar-->