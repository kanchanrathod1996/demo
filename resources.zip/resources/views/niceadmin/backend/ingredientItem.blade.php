@extends('niceadmin.backend.layouts.default')

@section('content') 

<main id="main" class="main">

    <div class="pagetitle">
        <h1>{!! (isset($ingredientItem)) ? 'Edit' : 'Add' !!} IngredientItem</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{!! url(ADMIN_SLUG.'/dashboard') !!}">Home</a></li>
                <li class="breadcrumb-item"><a href="{!! url(ADMIN_SLUG.'/ingredientItem') !!}">IngredientItem List</a></li>
                <li class="breadcrumb-item">IngredientItem</li>
            </ol>
        </nav>
    </div>

    <section class="section">
      <div class="row">

        <div class="col-lg-12">
            @include('niceadmin.backend.includes.notifications')
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title"></h6>
                    @if(isset($ingredientItem))
                        {!! Form::model($ingredientItem, ['route' => array('product.update', $product->id),'method' => 'PATCH', 'id' => 'category-form',  'class'=>"row g-3",'files' => true,'enctype' => 'multipart/form-data']) !!}
                    @else
                        {!! Form::open(['route' => 'product.store', 'id' => 'product-form', 'class'=>"row g-3",'files' => true]) !!}
                    @endif  
                     <!-- Accordion without outline borders -->
                     <div class="accordion accordion-flush" id="accordionFlushExample">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="flush-headingOne">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                                    Select product 
                                </button>
                            </h2>
                            <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                                <div class="accordion-body">
                                    {!! Form::label('Select ingredients', null, ['class'=>'form-label']) !!}
                                    {!! Form::select('product_id', $productList, null, ['class'=>'form-control', 'placeholder'=>'Please select ...']) !!}
                                </div>
                            </div>
                        </div>
                    </div><!-- End Accordion without outline borders -->   
                     <!-- Accordion without outline borders -->
                     <div class="accordion accordion-flush" id="accordionFlushExample2">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="flush-headingTwo">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
                                    Ingredients
                                </button>
                            </h2>
                            <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample2">
                                <div class="accordion-body">
                                    {!! Form::label('Select ingredients', null, ['class'=>'form-label']) !!}
                                    {!! Form::select('ingredient_id', $ingredientList, null, ['class'=>'form-control', 'placeholder'=>'Please select ...']) !!}
                                </div>
                            </div>
                        </div>
                    </div><!-- End Accordion without outline borders -->               
                        <div class="col-12">
                            {!! Form::label('Qunatity',null,['class'=>'form-label']) !!}
                            {!! Form::text('qunatity', old('qunatity'),['class'=>'form-control']) !!}
                        </div>
                        <div class="col-12">
                            {!! Form::label('Weight',null,['class'=>'form-label']) !!}
                            {!! Form::text('weight', old('weight'),['class'=>'form-control']) !!}
                        </div>
                        <div class="col-12">
                            {!! Form::label('Notes',null,['class'=>'form-label']) !!}
                            {!! Form::textarea('notes',old('notes'),['id'=>'notes','class'=>'form-control','rows'=>"2"]) !!}
                        </div>
                      
                        <div class="text-right">
                            {!! Form::submit('Submit',array('class'=>'btn btn-primary')) !!}
                            <a href="{!! url(ADMIN_SLUG.'/ingredientItem') !!}" class="btn btn-secondary">Cancel</a>
                        </div>
                    {!! Form::close()!!}
                </div>
            </div>

        </div>
      </div>
    </section>

  </main>

@endsection