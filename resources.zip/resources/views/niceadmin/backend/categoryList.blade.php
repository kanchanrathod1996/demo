@extends('niceadmin.backend.layouts.default')
@section('content') 
<main id="main" class="main">
    <div class="pagetitle">
      <h1>Category List</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="{{url(ADMIN_SLUG)}}">Home</a></li>
          <li class="breadcrumb-item">Category List</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title text-end"><a href="{{ url('admin/category/create') }}">Add Category</a></h5>

              <!-- Default Table -->
              <table class="table data-table" id="cat_list">
                <thead>
                  <tr>
                    <th scope="col">Category Name</th>
                    <th scope="col" >Status</th>
                    <th scope="col" >Action</th>
                  </tr>
                </thead>
                <tbody>

                </tbody>
              </table>
              <!-- End Default Table Example -->
            </div>
          </div>
      </div>
    </section>

  </main><!-- End #main -->
@endsection

@section('script')
<script>

    var table;

    $(function () {
      
      table = $('.data-table').DataTable({
            processing: true,
            serverSide: true,
            ajax: "{{ route('category.data') }}",
            columns: [
                {data: 'cat_name', name: 'cat_name'},
                {data: 'status', name: 'status'},
                {data: 'action', name: 'action', orderable: false, searchable: false},
            ]
        });
    });
    $("#cat_list").on('click', '.status-btn', function() {
        var id = $(this).attr('id');
        var r = confirm("Are you sure to change status?");
        if (!r) {
            return false
        }
        $.ajax({
            type: "POST",
            url: "{!! URL::to('admin/category/changeStatus') !!}",
            data: {
                id: id,
                _token:"{!! csrf_token() !!}"
            },
            dataType: 'json',
            beforeSend: function() {
                $(this).attr('disabled', true);
                $('.alert .msg-content').html('');
                $('.alert').hide();
            },
            success: function(resp) {
                if (resp.success) {
                    window.location.href=window.location.href
                    $('.alert-success .msg-content').html(resp.message);
                    $('.alert-success').show();
                } else {
                    $('.alert-danger .msg-content').html(resp.message);
                    $('.alert-danger').show();
                }
                $(this).attr('disabled', false);
                table.draw();
            },
            error: function(e) {
                alert('Error: ' + e);
            }
        });
    });
    $("#cat_list").on('click', '.delete-btn', function() {
        var id = $(this).attr('id');
        var r = confirm("Are you sure to delete this post?");
        if (!r) {
            return false
        }
        $.ajax({
            type: "POST",
            url: "category/" + id,
            data: {
                _method: 'DELETE',
                _token:"{!! csrf_token() !!}"
            },
            dataType: 'json',
            beforeSend: function() {
                $(this).attr('disabled', true);
                $('.alert .msg-content').html('');
                $('.alert').hide();
            },
            success: function(resp) {
                if (resp.success) {
                    $('.alert-success .msg-content').html(resp.message);
                    $('.alert-success').show();
                } else {
                    $('.alert-danger .msg-content').html(resp.message);
                    $('.alert-danger').show();
                }
                $(this).attr('disabled', false);
                table.draw();
            },
            error: function(e) {
                alert('Error: ' + e);
            }
        });
    });
</script>
@endsection