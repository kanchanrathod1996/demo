{{-- index page content --}}
@extends('niceadmin.backend.layouts.default')

@section('content')
<main id="main" class="main">
    <div class="pagetitle">
      <h1>Dashboard</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="{{url(ADMIN_SLUG.'/')}}">Home</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-12">
          <div class="row">
            <!-- User Card -->
            <div class="col-xxl-3 col-md-4">
              <div class="card info-card revenue-card shadow-lg p-3 mb-5 bg-white rounded">

                <div class="card-body">
                  <h5 class="card-title">Total User</h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-person"></i>
                    </div>
                    <div class="ps-3">
                      <h6>{{$userCount}}</h6>
                      <span class="text-success small pt-1 fw-bold"><i class="bi bi-arrow-right"></i></span> <a href="{{url(ADMIN_SLUG.'/user')}}" class="text-muted pt-2 ps-1">view more</a>

                    </div>
                  </div>
                </div>

              </div>
            </div><!-- End User Card -->

            <!-- Products Card -->
            <div class="col-xxl-3 col-md-4">
              <div class="card info-card revenue-card shadow-lg p-3 mb-5 bg-white rounded">

                <div class="card-body">
                  <h5 class="card-title">Total Products</h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-handbag-fill"></i>
                    </div>
                    <div class="ps-3">
                      <h6>{{$productCount}}</h6>
                      <span class="text-success small pt-1 fw-bold"><i class="bi bi-arrow-right"></i></span> <a href="{{url(ADMIN_SLUG.'/product')}}" class="text-muted pt-2 ps-1">view more</a>

                    </div>
                  </div>
                </div>

              </div>
            </div><!-- End Products Card -->

             <!-- Category Card -->
             <div class="col-xxl-3 col-md-4">
              <div class="card info-card revenue-card shadow-lg p-3 mb-5 bg-white rounded">

                <div class="card-body">
                  <h5 class="card-title">Total Categories</h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-stack"></i>
                    </div>
                    <div class="ps-3">
                      <h6>{{$categoryCount}}</h6>
                      <span class="text-success small pt-1 fw-bold"><i class="bi bi-arrow-right"></i></span> <a href="{{url(ADMIN_SLUG.'/category')}}" class="text-muted pt-2 ps-1">view more</a>

                    </div>
                  </div>
                </div>

              </div>
            </div>

            <!-- Tables Card -->
            <div class="col-xxl-3 col-md-4">
              <div class="card info-card revenue-card shadow-lg p-3 mb-5 bg-white rounded">

                <div class="card-body">
                  <h5 class="card-title">Total Tables</h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-stack"></i>
                    </div>
                    <div class="ps-3">
                      <h6>{{$tableCount}}</h6>
                      <span class="text-success small pt-1 fw-bold"><i class="bi bi-arrow-right"></i></span> <a href="{{url(ADMIN_SLUG.'/table')}}" class="text-muted pt-2 ps-1">view more</a>

                    </div>
                  </div>
                </div>

              </div>
            </div>

            <!-- Booking Card -->
            <div class="col-xxl-3 col-md-4">
              <div class="card info-card revenue-card shadow-lg p-3 mb-5 bg-white rounded">

                <div class="card-body">
                  <h5 class="card-title">Total Booking</h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-stack"></i>
                    </div>
                    <div class="ps-3">
                      <h6>{{$bookingCount}}</h6>
                      <span class="text-success small pt-1 fw-bold"><i class="bi bi-arrow-right"></i></span> <a href="{{url(ADMIN_SLUG.'/table')}}" class="text-muted pt-2 ps-1">view more</a>

                    </div>
                  </div>
                </div>

              </div>
            </div>

             <!-- Orders Card -->
             <div class="col-xxl-3 col-md-4">
              <div class="card info-card revenue-card shadow-lg p-3 mb-5 bg-white rounded">

                <div class="card-body">
                  <h5 class="card-title">Total Orders</h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-basket2-fill"></i>
                    </div>
                    <div class="ps-3">
                      <h6>3,264</h6>
                      <span class="text-success small pt-1 fw-bold"><i class="bi bi-arrow-right"></i></span> <a href="" class="text-muted pt-2 ps-1">view more</a>

                    </div>
                  </div>
                </div>

              </div>
            </div><!-- End orders Card -->
          </div>
        </div><!-- End Left side columns -->
      </div>
    </section>
</main><!-- End #main -->
@endsection


