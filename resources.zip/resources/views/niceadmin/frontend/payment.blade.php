@extends('niceadmin.frontend.layouts.default')
@section('content')
@if(Request::is('/'))
  <section class="food_section layout_padding-bottom">
@else
  <section class="food_section layout_padding">
@endif
  <div class="container">
    <div class="heading_container heading_center">
      <h2>
        Payment
      </h2>
    </div>
    <div class="row">     
      <div class="col-md-8 mt-3">
            <div class="card"> 
            <div class="card-body">
            </div>          
            </div>                     
      </div>
      <div class="col-md-4 mt-3">
          <div class="card">   
            <div class="card-body">
            </div>          
          </div>                     
    </div>
    </div>
  </div>
  </div>
  </section>
@endsection