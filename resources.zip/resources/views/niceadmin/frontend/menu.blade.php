@extends('niceadmin.frontend.layouts.default')
@section('content')
 <!-- menu section -->
 @include('niceadmin.frontend._menu')
 <!-- end menu section -->
</section>
@endsection
<!-- end food section -->

