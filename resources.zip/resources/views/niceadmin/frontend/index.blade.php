@extends('niceadmin.frontend.layouts.default')
@section('content')
  @include('niceadmin.frontend.offer')
  @include('niceadmin.frontend._menu')
  @include('niceadmin.frontend._about')
  @include('niceadmin.frontend._bookTable')
  @include('niceadmin.frontend.ourClient')
@endsection
