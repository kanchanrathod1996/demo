@extends('niceadmin.frontend.layouts.default')
@section('content')
@if(Request::is('/'))
  <section class="food_section layout_padding-bottom">
@else
  <section class="food_section layout_padding">
@endif
  <div class="container">
    <div class="heading_container heading_center">
      <h2>
        Shopping Cart
      </h2>
    </div>
    <div class="row">
      <div class="col-sm-12">
        @if(!$cart)
          <h1 style="text-align:center;">{{'your cart is empty'}}</h1>
        @else
      </div>
      <div class="clear"></div>
        
     
      <div class="col-md-12 mt-3">
          <div class="width_full mrgn_20t">
            <div  class="table-responsive">
              <table class="table table-hover table-border">
              <thead>
                <tr>
                  <th>Product Name</th>
                  <th>Qty</th>
                  <th>Price</th>
                  <th style="width:50px;"></th>
                  <th></th>                  
                </tr>
              </thead>
              <tbody>
                @foreach($cart as $key => $value)
                {{-- @dd($cart) --}}
                <tr id="product_row_{{ $value['id'] }}">
                  <td>{{$value['name']}}</td>
                  <td>
                    <div class="quantity">
                      <button class="quantity-button minus btn-danger" data-product-id="{{ $value['id'] }}">-</button>
                      <span id="quantity_{{ $value['id'] }}" data-quantity-change="{{$value['quantity']}}">{{ $value['quantity'] }}</span>
                      <button class="quantity-button plus btn-success" data-product-id="{{ $value['id'] }}">+</button>
                    </div>
                  </td>
                  {{-- <td>1</td> --}}
                  <td id="price_{{ $value['id'] }}" class="price"> {{$value['price']}}</td>                 
                  <td class="valign-center total-amount text-center"><img src="{{asset(PRODUCT_IMAGE_ROOT.$value['image'])}}" alt="" width="30"></td>                  
                  <td class="valign-center text-center"><a href="{!! url('/cart/remove/'.$key) !!}"  class="remove-item" data-product-id="" style="color: red;"><i class="fa fa-times"></i></a></td>      
                </tr>               
                @endforeach
              </tbody>                          
              </table>
            
            </div>
            <div class="width_full text-right">
              <label class="text-right total" >Total is : {{$total}}</label>
          </div>
          <div class="width_full text-right">
            <a href="{{url('/menu')}}" class="proceed-checkout-btn continue-shopping-btn btn btn-primary">Continue Shopping</a>
            
              <a href="{{url('/checkout')}}" class="proceed-checkout-btn btn btn-danger">Proceed to Checkout</a>
            
          </div>
        </div>
        @endif
      </div>
    </div>
  </div>
  </div>
  </section>
@endsection

@section('script')
<script>
    $(document).ready(function () {
      $(".quantity-button.minus").click(function () {
          var productId = $(this).data("product-id");
          var quantityElement = $(this).siblings("span");
          var currentQuantity = parseInt(quantityElement.text());
          if(currentQuantity > 1){
            quantityElement.text(currentQuantity - 1);
            var newQuentity = currentQuantity - 1;

                updateQuantity(productId,newQuentity);
                updatePrice(productId, newQuentity);
                // fetchPrices();
              quantityElement.text(newQuentity);
          } 

      });

      $(".quantity-button.plus").click(function () {
          var productId = $(this).data("product-id");
          var quantityElement = $(this).siblings("span");
          var currentQuantity = parseInt(quantityElement.text());
          if(currentQuantity <10){
            quantityElement.text(currentQuantity + 1);
            var newQuentity = currentQuantity + 1;
            // Promise.all([
              updateQuantity(productId,newQuentity);
              updatePrice(productId, newQuentity);
            // ]).then(fetchPrices);
            // fetchPrices();
            quantityElement.text(newQuentity);
            
          }
      });

    });

    function fetchPrices() {
      var total = 0;
      $('.price').each(function(){
        var price = parseFloat($(this).text());
        total +=price;
       });
       console.log(total);

       $(".total").text("Total is: " + total.toFixed(2)); // Update total price with 2 decimal places
    }

    function updatePrice(productId, newQuentity) {
      $.ajax({
          type: "POST",
          url: "{{ route('cart.updatePrice') }}",
          data: {
              productId: productId,
              newQuentity: newQuentity,
              _token: "{{ csrf_token() }}"
          },
          success: function(response) {
              var pricePerProduct = parseFloat(response.newTotalPrice);
              var total = parseFloat(response.total);
              $("#price_" + productId).text(pricePerProduct);
              fetchPrices();

              // $('.total').text('Total Price: ' + total);

          },
          error: function(xhr, status, error) {
              console.error(xhr.responseText);
          }
      });
    }

    function updateQuantity(productId, newQuentity) {
      $.ajax({
          type: "POST",
          url: "{{ route('cart.updateQuantity') }}",
          data: {
              productId: productId,
              quantityChange: newQuentity,
              _token: "{{ csrf_token() }}"
          },
          success: function(response) {
              // Update the quantity displayed in the view
              var newQuantity = response.newQuantity;
              $("#quantity_" + productId).text(newQuantity);
          },
          error: function(xhr, status, error) {
              console.error(xhr.responseText);
          }
      });
    }

</script>

@endsection
