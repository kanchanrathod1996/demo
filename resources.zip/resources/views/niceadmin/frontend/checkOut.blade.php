@extends('niceadmin.frontend.layouts.default')

@section('content')
    @php
        $isHomepage = Request::is('/');
    @endphp

    <section class="food_section {{ $isHomepage ? 'layout_padding-bottom' : 'layout_padding' }}">
        <div class="container">
            <div class="heading_container heading_center">
                <h2>Checkout</h2>
            </div>

            <div class="row">
                <div class="col-md-8 mt-3">
                    <div class="card">
                        <div class="card-body">
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="billAddress-tab" data-toggle="tab" href="#billAddress"
                                        role="tab" aria-controls="billAddress" aria-selected="true">Billing Address</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="shippingAdd-tab" data-toggle="tab" href="#shippingAdd"
                                        role="tab" aria-controls="shippingAdd" aria-selected="false">Shipping Address</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="order-tab" data-toggle="tab" href="#order" role="tab"
                                        aria-controls="order" aria-selected="false">Review Your Order</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="paymentType-tab" data-toggle="tab" href="#paymentType"
                                        role="tab" aria-controls="paymentType" aria-selected="false">Payment Type</a>
                                </li>
                            </ul>
                            @include('niceadmin.frontend.includes.notifications')

                            <form action="{{ route('checkout') }}" method="post" id="form"
                            name="form" role="form">
                            @csrf <!-- CSRF Token -->
                              <div class="tab-content" id="myTabContent">
                                  <div class="tab-pane fade show active" id="billAddress" role="tabpanel"
                                      aria-labelledby="billAddress-tab">
                                      <section class="book_section pt-3">
                                          <div class="container">
                                              <div class="heading_container">
                                                  <h2>User & Billing Details</h2>
                                              </div>

                                              <div class="form_container">                                               
                                                    <div class="row">
                                                        <div class="col-6">
                                                            <div class="form-group">
                                                              <input type="text" class="form-control" name="username"
                                                                  placeholder="Your Name" value="{{auth()->guard('client')->user()->username}}" required />
                                                                @error('username')
                                                                  <span class="text-danger">{{ $message }}</span>
                                                                @enderror
                                                            </div>
                                                        </div>
                                                        <div class="col-6">
                                                            <div class="form-group">
                                                                <input type="email" class="form-control" name="email"
                                                                    placeholder="Your Email" value="{{auth()->guard('client')->user()->email}}" required />
                                                                                                                                                                                        @error('username')
                                                                    <span class="text-danger">{{ $message }}</span>
                                                                    @enderror
                                                            </div>
                                                        </div>
                                                    </div>

                                                        <div class="row">
                                                            <div class="col-6">
                                                                <div class="form-group">
                                                                    <input type="text" class="form-control"
                                                                        name="contact_number" placeholder="Contact Number"
                                                                        value="{{auth()->guard('client')->user()->contact_number}}" required />
                                                                        @error('username')
                                                                        <span class="text-danger">{{ $message }}</span>
                                                                        @enderror
                                                                </div>
                                                            </div>
                                                            <div class="col-6">
                                                                <div class="form-group">
                                                                    <input type="text" class="form-control" name="address" required />
                                                                    @error('username')
                                                                        <span class="text-danger">{{ $message }}</span>
                                                                    @enderror
                                                                </div>
                                                            </div>
                                                        </div>
                                                      <div class="container text-center">
                                                        <a class="btn btn-primary" href="{{ url('/cart') }}">Back</a>
                                                        <a class="btn btn-success next-step">Next</a>
                                                      </div>
                                              </div>
                                          </div>
                                      </section>
                                  </div>

                                  <!-- Other Tabs -->
                                  <div class="tab-pane fade" id="shippingAdd" role="tabpanel"
                                      aria-labelledby="shippingAdd-tab">                                      
                                      <section class="book_section pt-3">
                                        <div class="container">
                                            <div class="heading_container">
                                                <h2>Shipping Details</h2>
                                            </div>
                                            <label class="control-label"><input type="checkbox" name="same_as"
                                                id="same_as"> <span> Same As Billing Address</span></label>
                                            <hr>

                                            @include('niceadmin.frontend.includes.notifications')

                                            <div class="form_container" id="ship_add">                                            
                                                    <div class="row">
                                                        <div class="col-6">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control" name="username"
                                                                placeholder="Your Name" value="{{auth()->guard('client')->user()->username}}" required />
                                                            </div>
                                                        </div>
                                                        <div class="col-6">
                                                            <div class="form-group">
                                                                <input type="email" class="form-control" name="email"
                                                                placeholder="Your Email" value="{{auth()->guard('client')->user()->email}}" required />
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="row">
                                                        <div class="col-6">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control"
                                                                name="contact_number1" placeholder="Contact Number"
                                                                value="{{auth()->guard('client')->user()->contact_number}}" required />
                                                            </div>
                                                        </div>
                                                        <div class="col-6">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control" name="address1" required />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="container text-center">
                                                      <a class="btn btn-primary prev-step">Back</a>
                                                      <a class="btn btn-success next-step">Next</a>
                                                    </div>
                                            </div>
                                        </div>
                                    </section>
                                </div>

                                  <div class="tab-pane fade" id="order" role="tabpanel" aria-labelledby="order-tab">
                                    <section class="book_section pt-3">
                                        <div class="container">
                                            <div class="heading_container">
                                                <h2>Review</h2>
                                            </div>

                                            @include('niceadmin.frontend.includes.notifications')

                                            <div class="col-md-12 mt-3">
                                                <div class="width_full mrgn_20t">
                                                  <div  class="table-responsive">
                                                    <table class="table table-hover table-border">
                                                    <thead>
                                                      <tr>
                                                        <th>Product Name</th>
                                                        <th>Qty</th>
                                                        <th>Price</th>
                                                        <th style="width:50px;"></th>
                                                      </tr>
                                                    </thead>
                                                    <tbody>
                                                        {{-- @dd($cart) --}}
                                                      @foreach($cart as $key => $value)
                                                      {{-- @dd($cart) --}}
                                                      <tr id="product_row_{{ $value['id'] }}">
                                                        <td>{{$value['name']}}</td>
                                                        <td>
                                                          <div class="quantity">
                                                            <button class="quantity-button minus btn-danger" data-product-id="{{ $value['id'] }}" disabled>-</button>
                                                            <span id="quantity_{{ $value['id'] }}" data-quantity-change="{{$value['quantity']}}">{{ $value['quantity'] }}</span>
                                                            <button class="quantity-button plus btn-success" data-product-id="{{ $value['id'] }}" disabled>+</button>
                                                          </div>
                                                        </td>
                                                        {{-- <td>1</td> --}}
                                                        <td id="price_{{ $value['id'] }}" class="price"> {{$value['price']}}</td>                 
                                                        <td class="valign-center total-amount text-center"><img src="{{asset(PRODUCT_IMAGE_ROOT.$value['image'])}}" alt="" width="30"></td>                                                                          
                                                      </tr>               
                                                      @endforeach
                                                    </tbody>                          
                                                    </table>
                                                    <div class="container text-center">
                                                        <a class="btn btn-primary prev-step" >Back</a>
                                                        <a class="btn btn-success next-step">Next</a>
                                                      </div>
                                                  </div>
                                                  
                                              </div>
                                            </div>
                                        </div>                                        
                                    </section>
                               
                                  </div>
                                  <div class="tab-pane fade" id="paymentType" role="tabpanel"
                                      aria-labelledby="paymentType-tab">
                                      <section class="book_section pt-3">
                                        <div class="container">
                                            <div class="heading_container">
                                                <h2>Choose Payment type</h2>
                                            </div>

                                            @include('niceadmin.frontend.includes.notifications')

                                            <div class="col-md-12 mt-3">
                                                <div class="width_full mrgn_20t">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <h5>Instamojo</h5>
                                                            <hr>
                                                            <p>
                                                                Lorem ipsum dolor sit amet, consectetur adipisicing elit ollit anim id est laborum.
                                                            </p>
                                                            <div class="radio">
                                                                <label class="color-active">
                                                                    <input type="radio" value="instamojo" id="instamojo" name="payment">
                                                                    Instamojo
                                                                </label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <h5>Stripe</h5>
                                                            <hr>
                                                            <p>
                                                                Lorem ipsum dolor sit amet, consectetur adipisicing elit ollit anim id est laborum.
                                                            </p>
                                                            <div class="radio">
                                                                <label class="color-active">
                                                                    <input type="radio" value="stripe" id="stripe" name="payment">
                                                                    Stripe
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>  
                                                    <hr>
                                                    <div class="container text-center">
                                                        <a class="btn btn-primary prev-step" >Back</a>
                                                          <input class="btn btn-success next-step" name="pay" type="submit" value="confirm payment" id="confirmButton">
                                                    </div>                                       
                                              </div>
                                            </div>
                                        </div>                                        
                                    </section>
                                  </div>
                              </div>
                          </form>

                        </div>
                    </div>
                </div>

                <!-- Sidebar (Order Summary) -->
                <div class="col-md-4 mt-3">
                    <div class="card">
                        <div class="card-body">
                            <!-- Order Summary Content -->
                            <div class="col">
                                <h5>Total</h5>
                                <hr>
                                <div class="row">
                                    <div class="col">
                                        Sub Total: 
                                    </div>     
                                    <div class="col">
                                        @php
                                            $totalPrice = 0;
                                        @endphp
                                        @if(Session::has('cart'))
                                            @foreach(Session::get('cart') as $item)                                                    
                                                @php
                                                    $totalPrice += $item['price']; // Add current item's price to total price
                                                @endphp
                                            @endforeach
                                        <p>{{ $totalPrice }}</p>                                    
                                        @else
                                            <p>Your cart is empty</p>
                                        @endif
                                    </div>  
                                </div>
                                <br/>
                                <div class="row">
                                    <div class="col">
                                        delivery charges:
                                    </div> 
                                    <div class="col">
                                        free
                                    </div>   
                                </div>                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
@section('script')
<script>
$(document).ready(function(){
    $("#same_as").change(function(){
        if ($(this).is(":checked")) {
            $("#ship_add").hide();
        } else {
            $("#ship_add").show();
        }
    });
    $(".prev-step").click(function(e) {
        var currentTab = $(".nav-tabs .nav-link.active");
        var prevTab = currentTab.parent().prev().find("a.nav-link");
        if(prevTab.length > 0) {
                prevTab.tab("show");
        }
    });
    
    $('.next-step').click(function(){
        if ($("#form").valid()) {
            var currentTab = $(".nav-tabs .nav-link.active");
            var nextTab = currentTab.parent().next().find("a.nav-link");
            nextTab.tab("show");
        }
    });     
});
</script>
@endsection