<!-- book section -->
<section class="book_section layout_padding">
    <div class="container">
      <div class="heading_container">
        <h2>
          Book A Table
        </h2>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form_container">
            @include('niceadmin.frontend.includes.notifications')
            <form action="{{url('/bookTable')}}" method="post">
              @csrf
              <div>
                <input type="text" class="form-control" name="username" value="{{isset(auth()->guard('client')->user()->username)?auth()->guard('client')->user()->username : ''}}" placeholder="Your Name" disabled/>
              </div>
              <div>
                <input type="text" class="form-control" name="contact_number" value="{{isset(auth()->guard('client')->user()->contact_number)?auth()->guard('client')->user()->contact_number : ''}}" placeholder="Phone Number" disabled/>
              </div>
              <div>
                <input type="email" class="form-control" name="email" value="{{isset(auth()->guard('client')->user()->email)?auth()->guard('client')->user()->email : ''}}" placeholder="Your Email" disabled/>
              </div>
              
              <div>
                <input type="text" class="form-control" name="number_of_guests" id="capacityInput" placeholder="Number of people"/>
              </div>
              <div>
                  <select class="form-control wide" name="table_id" id="tableList">
                    <option value="">Select Table
                    </option>                 
                  </select>
              </div>
            
              <div>
                <input type="text" class="form-control" name="book_date" id="example" placeholder="Please select DateandTime">
              </div>             
              <div class="btn_box">
                <button id="bookNow">
                  Book Now
                </button>
              </div>
            </form>
          </div>
        </div>
        <div class="col-md-6">
          <div class="map_container ">
            {{-- <div id="googleMap"> --}}
              <div class="myMap">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d567369.5496330137!2d70.57082627190104!3d22.317550510687003!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3959ca27f44eb8bd%3A0x3c58c28d4bbdd5b4!2sSiddhi%20Vinayak%20Infocom%20Pvt.%20Ltd.!5e0!3m2!1sen!2sus!4v1709200130043!5m2!1sen!2sus" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- end book section -->
  {{-- datetime picke --}}
  @section('script')
    <script>
      $(function () {
//        var  busy['2017-03-19 11:00', '2017-05-09 15:30'];
// var holidays['2017-12-31'];
        $('#example').datetimepicker(
          {

            // minDate: moment().startOf('day'),
            minDate: moment(), // Set minimum selectable date and time to current date and time
            maxDate: moment().endOf('day'), // Set maximum selectable date to end of the current day
        // defaultDate: moment().startOf('day'),
          sideBySide: true,
          }
        );
        
        $('#capacityInput').on('change',function() {
          var capacity = $(this).val();
          
          $.ajax({
              url: 'changeTable',
              type: 'GET',
              data: {
                  capacity: capacity
              },
              success: function(response) {
                  $('#tableList').empty();
                  if(response.tables){
                    $.each(response.tables, function(index, table) {
                      $('#tableList').append('<option value="' + table.id + '">T' + table.table_number + '</option>');
                  });
                  }else{
                    $('#tableList').append('<option value="">'+response.message+'</option>');
                  }
                  
                  // $('#tableList').removeAttr('style');

              },
              error: function(xhr, status, error) {
                  console.error(error);
              }
          });
        });        
    });
    </script>
   
  @endsection