@extends('niceadmin.frontend.layouts.default')
@section('content')
@if(Request::is('/'))
  <section class="food_section layout_padding-bottom">
@else
  <section class="food_section layout_padding">
@endif
  <div class="container">
    <div class="row">
        <div class="col-md-6">
            <div class="food_image">
                <img src="https://via.placeholder.com/400" alt="Food Image">
              </div>      
        </div>
        <div class="col-md-7 col-lg-6 ">
            <div class="detail-box">               
                <h2>Food Name</h2>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dignissimos quos excepturi sit in? Assumenda dicta, vero ex accusantium veritatis dolorum ratione odio quae quas esse tempora, nihil temporibus vel placeat.Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dignissimos quos excepturi sit in? Assumenda dicta, vero ex accusantium veritatis dolorum ratione odio quae quas esse tempora, nihil temporibus vel placeat.Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dignissimos quos excepturi sit in? Assumenda dicta, vero ex accusantium veritatis dolorum ratione odio quae quas esse tempora, nihil temporibus vel placeat.Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dignissimos quos excepturi sit in? Assumenda dicta, vero ex accusantium veritatis dolorum ratione odio quae quas esse tempora, nihil temporibus vel placeat.</p>
                    <p class="h1"><span class="badge badge-info" style="font-family:'Dancing Script', cursive;">Price :</span>10.99</p>
                <!-- Additional food information can be added here -->
                <div class="btn-box justify-content-start">
                    <a href="" >
                      Add to cart
                    </a>
                </div>
            </div>
        </div>
    </div>
  </div>
  </section>
@endsection
