{{-- login --}}
@extends('niceadmin.frontend.layouts.default')
@section('content')

<section class="book_section layout_padding">
  <div class="container">
    <div class="heading_container heading_center">
      <h2>
        Login
      </h2>
    </div>
    <div class="card m-auto p-3 border-0" style="width: 50%;">
      <div class="shadow-lg p-3 mb-5 bg-white rounded">
        <div class="card-body">
          @include('niceadmin.frontend.includes.notifications')
          <div class="row">
            <div class="col-md-12">
              <div class="form_container">
                <form action="{{url('/login')}}" method="post" role="form" name="login-form" id="login-form">   
                  @csrf               
                  <div>
                    <input type="email" class="form-control" name="email" placeholder="Your Email"/>
                  </div>
                  <div>
                    <input type="password" class="form-control" name="password" placeholder="Your password"/>
                  </div>
       
                  <div class="btn_box text-center">
                    <button id="login">
                      Login
                    </button>
                  </div>
                </form>
                <div class="row mt-3">
                  <div class="col text-start">
                    <a href="{{url('forgotPassword')}} ">Forgot Password</a>
                  </div>
                  <div class="col text-right">
                    <a href="{{url('signup')}} ">Create a new accout</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- end food section -->
@endsection
