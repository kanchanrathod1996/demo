@extends('niceadmin.frontend.layouts.default')
@section('content')
 <!-- about section -->
  @include('niceadmin.frontend._about')
  <!-- end about section -->
@endsection