@extends('niceadmin.frontend.layouts.default')
@section('content')
@if(Request::is('/'))
  <section class="food_section layout_padding-bottom">
@else
  <section class="food_section layout_padding">
@endif
    <div class="container">
        <div class="heading_container heading_center">
        <h2>
            Laravel Instamojo Payment Integration
        </h2>
        </div>
        <div class="row">     
        <div class="col-md-8 mt-3">
                <div class="card bg-body"> 
                    <div class="card-body">
                      <div class="text-center">
                        <img src="{{asset('user/assets/images/instamojo_logo.webp')}}" border="0" alt="Instamojo Logo">
                      </div>
                      <div class="text-center mt-3">
                        <a href="{{ route('instamojo') }}" class="btn btn-success">Pay with Instamojo(<span>&#8377;</span>{!! $total !!} )</a>
                      </div>
                    </div>          
                  </div>                     
        </div>
        </div>
    </div>
  </section>
@endsection