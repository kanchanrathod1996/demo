<!-- slider section -->
<section class="slider_section ">
  <div id="customCarousel1" class="carousel slide" data-ride="carousel">
    <div class="carousel-inner">
      @foreach ($slides as $key=>$slide)          
        <div class="carousel-item {{ $key === 0 ? ' active' : '' }}">
          <div class="container ">
            <div class="row">
              <div class="col-md-7 col-lg-6 ">
                <div class="detail-box">
                  <h1>
                    {{$slide->title}}
                  </h1>
                  <p>
                    {{$slide->description}}
                  </p>
                  <div class="btn-box">
                    <a href="" class="btn1">
                      Order Now
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      @endforeach

      {{-- <div class="carousel-item ">
        <div class="container ">
          <div class="row">
            <div class="col-md-7 col-lg-6 ">
              <div class="detail-box">
                <h1>
                  Fast Food Restaurant
                </h1>
                <p>
                  Doloremque, itaque aperiam facilis rerum, commodi, temporibus sapiente ad mollitia laborum quam quisquam esse error unde. Tempora ex doloremque, labore, sunt repellat dolore, iste magni quos nihil ducimus libero ipsam.
                </p>
                <div class="btn-box">
                  <a href="" class="btn1">
                    Order Now
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="carousel-item">
        <div class="container ">
          <div class="row">
            <div class="col-md-7 col-lg-6 ">
              <div class="detail-box">
                <h1>
                  Fast Food Restaurant
                </h1>
                <p>
                  Doloremque, itaque aperiam facilis rerum, commodi, temporibus sapiente ad mollitia laborum quam quisquam esse error unde. Tempora ex doloremque, labore, sunt repellat dolore, iste magni quos nihil ducimus libero ipsam.
                </p>
                <div class="btn-box">
                  <a href="" class="btn1">
                    Order Now
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div> --}}
    </div>
    <div class="container">
      <ol class="carousel-indicators">
        @foreach ($slides as $key=>$slide)          
          <li data-target="#customCarousel1" data-slide-to="{{ $key }}" class="{{ $key == 0 ? 'active' : '' }}"></li>
        @endforeach

          {{-- <li data-target="#customCarousel1" data-slide-to="1"></li>
          <li data-target="#customCarousel1" data-slide-to="2"></li> --}}
      </ol>
    </div>
  </div>

</section>
