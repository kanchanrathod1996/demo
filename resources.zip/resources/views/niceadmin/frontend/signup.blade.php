{{-- login --}}
@extends('niceadmin.frontend.layouts.default')
@section('content')

<section class="book_section layout_padding">
  <div class="container">
    <div class="heading_container heading_center">
      <h2>Sign Up</h2>
    </div>
    <div class="card m-auto p-3 border-0" style="width: 50%;">
      <div class="shadow-lg p-3 mb-5 bg-white rounded">
        <div class="card-body">
          @include('niceadmin.frontend.includes.notifications')

          <div class="row">
            <div class="col-md-12">
              <div class="form_container">
                <form action="{{url('/signup')}}" method="post" role="form" name="registration-form" id="registration-form">
                  @csrf <!-- CSRF Token -->
                  
                  <!-- Username -->
                  <div>
                    <input type="text" class="form-control" name="username" placeholder="Your Name" required />
                  </div>
                  
                  <!-- Email -->
                  <div>
                    <input type="email" class="form-control" name="email" placeholder="Your Email" required />
                  </div>
                  
                  <!-- Password -->
                  <div>
                    <input type="password" class="form-control" name="password" placeholder="Your password" required>
                  </div>  
                  
                  <!-- Confirm Password -->
                  <div>
                    <input type="password" class="form-control" name="confirm_password" placeholder="Confirm Password" required>
                  </div>     
                                    
                  <!-- Contact Number -->
                  <div>
                    <input type="text" class="form-control" name="contact_number" placeholder="Contact Number" required />
                  </div>
                  
                  <!-- Sign Up Button -->
                  <div class="btn_box text-center">
                    <button id="SignUp">Sign Up</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- end food section -->
@endsection
