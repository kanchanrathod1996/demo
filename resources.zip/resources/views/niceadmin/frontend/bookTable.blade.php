@extends('niceadmin.frontend.layouts.default')
@section('content')
<!-- book section -->
  @include('niceadmin.frontend._bookTable')
<!-- end book section -->
@endsection