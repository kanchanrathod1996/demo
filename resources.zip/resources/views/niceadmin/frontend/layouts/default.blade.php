<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <link rel="shortcut icon" href="{{asset('user/assets/images/favicon.png')}}" type="">

  <title> Feane </title>

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="{{asset('user/assets/css/bootstrap.css')}}" />

  <!--owl slider stylesheet -->
  <link rel="stylesheet" type="text/css" href="{{asset('user/assets/css/OwlCarousel2-2.3.4/docs/assets/owlcarousel/assets/owl.carousel.min.css')}}" />
  {{-- <!-- nice select  -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-nice-select/1.1.0/css/nice-select.min.css" integrity="sha512-CruCP+TD3yXzlvvijET8wV5WxxEh5H8P4cmz0RFbKK6FlZ2sYl3AEsKlLPHbniXKSrDdFewhbmBK5skbdsASbQ==" crossorigin="anonymous" /> --}}
  <!-- font awesome style -->
  <link href="{{ asset('user/assets/css/font-awesome.min.css')}}" rel="stylesheet" />

  <!-- Custom styles for this template -->
  <link href="{{asset('user/assets/css/style.css')}}" rel="stylesheet" />
  <!-- responsive style -->
  <link href="{{asset('user/assets/css/responsive.css')}}" rel="stylesheet" />
  {{-- datetimepicker --}}
  <link rel="stylesheet" href="{{asset('user/assets/Date-Time-Picker-Bootstrap-4/build/css/bootstrap-datetimepicker.min.css')}}">

</head>

@if(Request::is('/')) 
  <body>
@else
  <body class="sub_page">
@endif

  <div class="hero_area">
    <div class="bg-box">
       <img src="{{asset('user/assets/images/hero-bg.jpg')}}" alt="">
    </div>
      @include('niceadmin.frontend.includes.header')
      @if(Request::is('/')) 
        @include('niceadmin.frontend.slider')
      @endif
  </div>
        @yield('content')
    @include('niceadmin.frontend.includes.footer')

  <!-- jQery -->
  <script src="{{asset('user/assets/js/jquery-3.4.1.min.js')}}"></script>  
{{-- validation --}}
<script src="{{asset('user/assets/js/jquery.validate.min.js')}}"></script>
<script src="{{asset('assets/t_admin/assets/js/jquery-ui-1.13.2.custom/jquery-ui.min.js')}}"></script>
<script src="{{asset('user/assets/js/additional-methods.js')}}"></script>

 <!-- bootstrap js -->
  <script src="{{asset('user/assets/js/bootstrap.js')}}"></script>

  <!-- popper js -->
  <script src="{{asset('user/assets/js/popper.min.js')}}"></script>

  <!-- owl slider -->
  <script src="{{asset('user/assets/css/OwlCarousel2-2.3.4/docs/assets/owlcarousel/owl.carousel.min.js')}}">
  </script>
  <!-- isotope js -->
  <script src="{{asset('user/assets/js/isotope.pkgd.min.js')}}"></script>
  <!-- nice select -->
  {{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-nice-select/1.1.0/js/jquery.nice-select.min.js"></script> --}}
  <!-- custom js -->
  <script src="{{asset('user/assets/js/custom.js')}}"></script>
  <!-- Google Map -->
  {{-- <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCh39n5U-4IoWpsVGUHWdqB6puEkhRLdmI&callback=myMap">
  </script> --}}
  <!-- End Google Map -->
  <!-- Moment.js -->
  <script src="{{asset('user/assets/js/moment.min.js')}}"></script>
  {{-- datetime --}}
  <script src="{{asset('user/assets/Date-Time-Picker-Bootstrap-4/build/js/bootstrap-datetimepicker.min.js')}}"></script>
  @yield('script')
</body>

</html>