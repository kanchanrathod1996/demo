@extends('admin.layouts.default')

@section('content')  

<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid m-2">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h3 class="m-0">Dashboard</h3><a href="{!! '/admin/addStudent' !!}" class="">Add Student</a>
                </div>
            </div>
        </div>
    </div>
    {{-- @dd($new_bookingList); --}}
    @include('admin.includes.notification')
    
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-border-light shadow-none p-3 mb-5 bg-body-tertiary rounded">
                        <div class="card-header">
                            <h5 class="card-title">Student List</h5>
                        </div>
                        <div class="card-body">
                            <table class="table" id="student-list">
                                <thead>
                                  <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Phone</th>
                                    <th scope="col">Action</th>

                                  </tr>
                                </thead>
                                <tbody class="table-group-divider">
                                    @foreach ($students as $student)
                                        <tr>
                                            <th scope="row">{{$student->id}}</th>
                                            <td>{{$student->name}}</td>
                                            <td>{{$student->email}}</td>
                                            <td>{{$student->phone}}</td>
                                            <td><a href="edit/{{ $student->id }}" class="edit-btn">Edit</a> | <a href="#" class="delete-btn" data-id="{{ $student->id }}">Delete</a></td>
                                        </tr>    
                                    @endforeach                    
                                </tbody>
                              </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

</div>

@endsection

@section('script')
    <script type="text/javascript">
         $(function() {
            $('#student-list').on('click','.delete-btn',function() {
                var id = $(this).attr('data-id');
                var r = confirm("Are you sure to delete this student?");
                if (!r) {
                    return false
                }
                $.ajax({
                    type: "GET",
                    url: "delete/" + id,
                    dataType: 'json',
                    success: function(resp) {
                         window.location.href = '/admin/dashboard'
                    },
                    error: function(e) {
                        alert('Error: ' + e);
                    }

                });
            });
         });
    </script>
@endsection