@extends('admin.layouts.default')

@section('content')  
    <div class="container-sm">
        <div class="card mt-3" style="margin:auto; padding:10px; width:35%">
            <h2 class="card-header text-center text-black">Admin Login</h2>
            <div class="card-body">
                <p class="card-title text-center mb-4">Sign in to start your session</p>
                @include('admin.includes.notification')

                @if(isset($student))
                            {!! Form::model($student, array('url'=>'api/student/edit/'.$student->id, 'method' => 'POST', 'id' => 'student-form', 'files' => true )) !!}
                        @else
                        {!! Form::open(['url' => 'api/student','method'=>'POST','id'=>'student-form','enctype'=>'multipart/form-data']) !!}
                        @endif
                        {!! Form::hidden('student_id', isset($student) ? $student->id : 0 ,array('id'=>'student')) !!}

                <div class="mb-3">
                    <label class="form-label">User Name</label>
                    <input type="text" class="form-control" name="username" id="username" placeholder="Enter user name" value="{!! isset($student) ? $student->username : old('name') !!}">
                </div>
                <div class="mb-3">
                    <label  class="form-label">Email</label>
                    <input type="email" class="form-control" name="email" value="{!! isset($student) ? $student->email : old('email') !!}" id="email" placeholder="Enter your email">
                </div>
                @if(!isset($student))  
                    <div class="mb-3">
                        <label  class="form-label">Password</label>
                        <input type="password" class="form-control" name="password" id="password" placeholder="Enter your password">
                    </div>  
                    <div class="mb-3">
                        <label  class="form-label">Confirm Password</label>
                        <input type="password" class="form-control" name="confirm_password" id="confirm_password" placeholder="Re-Enter your password">
                    </div>  
                @endif
                <div class="mb-3">
                    <label  class="form-label">phone</label>
                    <input type="text" class="form-control" name="phone" id="phone" value="{!! isset($student) ? $student->phone : old('phone') !!}" placeholder="Enter your phone">
                </div>            
            </div>
            <button type="submit" class="btn btn-block btn-primary">@if(!isset($student)) {{'Add Student'}} @else {{'Update Student'}} @endif</button>
    
                {!! Form::close() !!}
        </div>
    </div>
    </div>
@endsection
